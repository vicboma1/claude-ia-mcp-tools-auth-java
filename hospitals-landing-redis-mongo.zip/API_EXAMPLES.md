# 🔗 Ejemplos de API - MongoDB Snapshots

## 📍 Base URL
```
http://localhost:8080
```

## 1️⃣ Listar Snapshots de una Tab

### Request
```bash
curl -X GET "http://localhost:8080/api/admin/search-snapshots/tab/subscribers" \
  -H "Content-Type: application/json"
```

### Response (200 OK)
```json
[
  {
    "id": "507f1f77bcf86cd799439011",
    "tab": "subscribers",
    "action": "LIST",
    "results": [
      {
        "id": 1,
        "email": "juan@example.com",
        "createdAt": "2024-09-04T10:15:30Z"
      }
    ],
    "resultCount": 1,
    "timestamp": "2024-09-04T10:30:00Z",
    "performedBy": "system",
    "details": "Búsqueda/listado general"
  }
]
```

## 2️⃣ Listar Snapshots por Acción

### Request - Crear nuevos
```bash
curl -X GET "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE" \
  -H "Content-Type: application/json"
```

### Request - Eliminar
```bash
curl -X GET "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/DELETE" \
  -H "Content-Type: application/json"
```

### Request - Listar
```bash
curl -X GET "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/LIST" \
  -H "Content-Type: application/json"
```

## 3️⃣ Snapshots por Rango de Fechas

### Request
```bash
curl -X GET "http://localhost:8080/api/admin/search-snapshots/date-range" \
  -G \
  --data-urlencode "start=2024-09-01T00:00:00Z" \
  --data-urlencode "end=2024-09-05T23:59:59Z" \
  -H "Content-Type: application/json"
```

O más simple:
```bash
curl "http://localhost:8080/api/admin/search-snapshots/date-range?start=2024-09-01T00:00:00Z&end=2024-09-05T23:59:59Z"
```

## 4️⃣ Snapshots por Tab y Rango de Fechas

### Request
```bash
curl "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/date-range" \
  -G \
  --data-urlencode "start=2024-09-04T00:00:00Z" \
  --data-urlencode "end=2024-09-04T23:59:59Z"
```

## 5️⃣ Contar Snapshots de una Tab

### Request
```bash
curl -X GET "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/count" \
  -H "Content-Type: application/json"
```

### Response (200 OK)
```json
42
```

## 🎯 Ejemplos Prácticos (Con jq)

### Contar total de operaciones CREATE
```bash
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE" | jq 'length'
```

### Ver el último email creado
```bash
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE" | jq '.[0].results[0].email'
```

### Filtrar snapshots de hoy
```bash
FECHA=$(date +"%Y-%m-%dT00:00:00Z")
FECHA_FIN=$(date -u +"%Y-%m-%dT23:59:59Z")
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/date-range?start=$FECHA&end=$FECHA_FIN" | jq '.[] | {action, timestamp, resultCount}'
```

### Ver todos los emails que han sido creados
```bash
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE" \
  | jq '.[] | .results[] | .email'
```

### Ver histórico de cambios en resultCount
```bash
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/LIST" \
  | jq '.[] | {timestamp, resultCount}'
```

## 💾 Descargar JSON a Archivo

### Descargar todos los snapshots
```bash
curl "http://localhost:8080/api/admin/search-snapshots/tab/subscribers" \
  > snapshots.json
```

### Descargar solo CREATEs
```bash
curl "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE" \
  > snapshots-creates.json
```

### Descargar con formato Pretty (2 espacios)
```bash
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers" \
  | jq '.' \
  > snapshots-pretty.json
```

## 🔄 Scripts de Ejemplo

### Monitorear cambios cada 5 segundos
```bash
#!/bin/bash
while true; do
  echo "=== $(date) ==="
  curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/count"
  sleep 5
done
```

### Exportar histórico por acción
```bash
#!/bin/bash
for action in CREATE DELETE LIST; do
  curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/$action" \
    | jq . > "snapshots-$action.json"
  echo "✅ Exportado: snapshots-$action.json"
done
```

### Analizar patrones de cambio
```bash
#!/bin/bash
echo "Snapshots CREATE:"
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE" | jq 'length'

echo "Snapshots DELETE:"
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/DELETE" | jq 'length'

echo "Snapshots LIST:"
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/LIST" | jq 'length'

echo "Total:"
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/count"
```

## 🧪 Test Completo (Bash)

```bash
#!/bin/bash

API_BASE="http://localhost:8080/api/admin/search-snapshots"
TAB="subscribers"

echo "🧪 Test Completo de API"
echo "======================"
echo ""

# Test 1: Contar snapshots
echo "✅ Test 1: Contar snapshots"
TOTAL=$(curl -s "$API_BASE/tab/$TAB/count")
echo "Total: $TOTAL"
echo ""

# Test 2: Listar por acción
echo "✅ Test 2: Snapshots por acción"
for action in CREATE DELETE LIST; do
  COUNT=$(curl -s "$API_BASE/tab/$TAB/action/$action" | jq 'length')
  echo "  $action: $COUNT"
done
echo ""

# Test 3: Listar por rango de fechas
echo "✅ Test 3: Snapshots de hoy"
TODAY=$(date +"%Y-%m-%dT00:00:00Z")
TODAY_END=$(date -u +"%Y-%m-%dT23:59:59Z")
RANGE=$(curl -s "$API_BASE/tab/$TAB/date-range?start=$TODAY&end=$TODAY_END" | jq 'length')
echo "Snapshots de hoy: $RANGE"
echo ""

echo "✨ Tests completados"
```

## 📊 Estadísticas (con jq)

### Contar emails únicos creados
```bash
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE" \
  | jq -r '.[].results[].email' | sort -u | wc -l
```

### Ver último timestamp registrado
```bash
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers" \
  | jq -s '.[0].timestamp'
```

### Promedios de resultCount
```bash
curl -s "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/LIST" \
  | jq '[.[].resultCount] | (add/length)'
```

## ⚠️ Códigos de Error

| Código | Significado | Solución |
|--------|------------|----------|
| 200 | OK | ✅ Funciona |
| 400 | Bad Request | Revisa fechas en formato ISO8601 |
| 404 | Not Found | Tab o acción no existen |
| 500 | Server Error | Revisa logs, MongoDB no conecta |

## 🔐 Con Autenticación (Cuando esté implementada)

```bash
# Con Basic Auth
curl -u admin:changeme "http://localhost:8080/api/admin/search-snapshots/tab/subscribers"

# Con Bearer Token (si está configurado)
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "http://localhost:8080/api/admin/search-snapshots/tab/subscribers"
```

## 📱 Cliente Python

```python
import requests
import json
from datetime import datetime, timedelta

BASE_URL = "http://localhost:8080/api/admin/search-snapshots"

# Obtener snapshots de una tab
def get_snapshots(tab="subscribers"):
    response = requests.get(f"{BASE_URL}/tab/{tab}")
    return response.json()

# Obtener snapshots por acción
def get_snapshots_by_action(tab="subscribers", action="CREATE"):
    response = requests.get(f"{BASE_URL}/tab/{tab}/action/{action}")
    return response.json()

# Obtener snapshots por rango de fechas
def get_snapshots_by_date_range(start, end, tab="subscribers"):
    params = {
        "start": start.isoformat() + "Z",
        "end": end.isoformat() + "Z"
    }
    response = requests.get(f"{BASE_URL}/tab/{tab}/date-range", params=params)
    return response.json()

# Contar snapshots
def count_snapshots(tab="subscribers"):
    response = requests.get(f"{BASE_URL}/tab/{tab}/count")
    return response.json()

# Uso
if __name__ == "__main__":
    print("Snapshots total:", count_snapshots())
    print("CREATEs:", len(get_snapshots_by_action("subscribers", "CREATE")))
    
    # Últimos 7 días
    end = datetime.utcnow()
    start = end - timedelta(days=7)
    recent = get_snapshots_by_date_range(start, end)
    print(f"Snapshots últimos 7 días: {len(recent)}")
```

---

💡 **Tip**: Usa `jq` para parsear JSON en la terminal:
```bash
curl -s "..." | jq '.[] | {action, timestamp}'
```
