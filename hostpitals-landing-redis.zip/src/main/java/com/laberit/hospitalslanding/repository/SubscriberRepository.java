package com.laberit.hospitalslanding.repository;

import com.laberit.hospitalslanding.model.Subscriber;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SubscriberRepository extends JpaRepository<Subscriber, Long> {

    Optional<Subscriber> findByEmailIgnoreCase(String email);

    boolean existsByEmailIgnoreCase(String email);
}
