# Panel de Administración de Redis

## ✅ Interfaz Web Completada

Se ha agregado un panel interactivo en el admin para gestionar Redis directamente desde el navegador.

### 🎨 **Cambios en el Frontend**

#### 1. **Actualización de admin.html**
- ✅ Sistema de pestañas (Suscriptores | Redis)
- ✅ Interfaz para gestionar claves-valor
- ✅ Formulario para agregar nuevas claves
- ✅ Lista de claves con opciones Editar/Eliminar
- ✅ Contador de claves almacenadas
- ✅ Mensajes de estado y confirmación

#### 2. **Nuevo archivo: admin-redis.js**
- ✅ Clase RedisApi para comunicarse con los endpoints
- ✅ Manejo de autenticación HTTP Basic
- ✅ Funciones CRUD completas
- ✅ Gestión de errores con feedback visual
- ✅ Escapado de HTML para prevenir XSS

### 🖥️ **Características del Panel Redis**

#### **Agregar Nueva Clave**
```
1. Ingresa la clave (key)
2. Ingresa el valor (value)
3. Haz clic en "Agregar" o presiona Enter
4. ✓ Confirmación visual en pantalla
```

#### **Listar Todas las Claves**
```
- Vista de tabla con todas las claves y sus valores
- Contador total de claves
- Actualización automática al agregar/editar/eliminar
```

#### **Editar un Valor**
```
1. Haz clic en "Editar" en la fila de la clave
2. Modifica el valor en el prompt
3. ✓ Cambio inmediato en la UI
```

#### **Eliminar una Clave**
```
1. Haz clic en "Eliminar" en la fila de la clave
2. Confirma la eliminación
3. ✓ Clave removida de Redis
```

### 🔒 **Seguridad**

- ✅ Autenticación HTTP Basic (credenciales: admin:changeme)
- ✅ Escapado de HTML para prevenir XSS
- ✅ Confirmaciones antes de operaciones destructivas
- ✅ Solo accesible para usuarios autenticados
- ✅ Validación de inputs en cliente y servidor

### 🎯 **Flujo de Uso**

**Acceder al panel:**
```
1. Navega a http://localhost:8080/admin.html
2. Usa las credenciales:
   - Usuario: admin
   - Contraseña: changeme
3. Haz clic en la pestaña "Redis"
```

**Ejemplo: Almacenar configuración**
```
Clave: api_key
Valor: sk_live_1234567890abcdef

Clave: cache_ttl
Valor: 3600

Clave: db_host
Valor: prod-db-01.example.com
```

### 💬 **Mensajes de Feedback**

| Mensaje | Significado |
|---------|------------|
| ✓ Clave agregada correctamente | Operación exitosa |
| ✓ Clave actualizada correctamente | Cambio guardado |
| ✓ Clave eliminada correctamente | Eliminación completada |
| ✗ Error: ... | Error en la operación |
| ⚠️ La clave y el valor no pueden estar vacíos | Validación fallida |

### 🌐 **API Endpoints Utilizados**

```
GET    /api/admin/redis/all                 - Listar todas las claves
POST   /api/admin/redis                     - Crear nueva clave
PUT    /api/admin/redis/{key}               - Actualizar valor
DELETE /api/admin/redis/{key}               - Eliminar clave
```

### 🎨 **Estilos CSS Incluidos**

- ✅ Diseño responsive
- ✅ Animaciones suaves
- ✅ Tema coherente con el rest de la app
- ✅ Estados de interacción clara
- ✅ Contraste accesible

### 📁 **Archivos Modificados/Creados**

```
src/main/resources/static/
├── admin.html (MODIFICADO - añadidas pestañas y sección Redis)
└── js/
    └── admin-redis.js (NUEVO - lógica de Redis)
```

### 🔄 **Flujo Técnico**

```
1. Usuario escribe clave/valor en el formulario
   ↓
2. JavaScript captura el evento y valida inputs
   ↓
3. Realiza request POST a /api/admin/redis
   ↓
4. Spring Security valida credenciales (HTTP Basic)
   ↓
5. AdminRedisController procesa la solicitud
   ↓
6. RedisService ejecuta operación en Redis
   ↓
7. Response JSON se devuelve al navegador
   ↓
8. JavaScript actualiza la UI con el resultado
   ↓
9. Se muestra mensaje de confirmación
```

### ⌨️ **Atajos de Teclado**

| Atajo | Acción |
|-------|--------|
| Enter (en campo Key) | Mueve el foco al campo Value |
| Enter (en campo Value) | Haz clic en "Agregar" |
| Botón Actualizar | Recarga la lista de claves |

### 🎓 **Casos de Uso Comunes**

#### 1. **Almacenar Variables de Configuración**
```
database_host → prod-db-server.example.com
cache_timeout → 1800
max_connections → 100
```

#### 2. **Gestionar Claves API Temporales**
```
twilio_auth_token → ac1234567890abcdef
stripe_api_key → sk_live_...
sendgrid_key → SG.abcd1234...
```

#### 3. **Control de Feature Flags**
```
feature_new_dashboard → enabled
beta_testing_mode → disabled
maintenance_mode → false
```

#### 4. **Cachés y Sesiones**
```
user_session_12345 → {"id": 12345, "name": "John"}
cached_hospital_list → {"version": "1.2.3", "count": 245}
```

### 🚀 **Próximos Pasos Recomendados**

1. Implementar TTL (Time To Live) editable por clave
2. Agregar búsqueda/filtrado de claves
3. Implementar paginación para muchas claves
4. Agregar exportación/importación de keys (JSON)
5. Implementar historial de cambios
6. Agregar soporte para tipos de datos Redis avanzados (hashes, sets, listas)

---

**Estado**: ✅ Completado y Funcional
**Fecha**: 2 de Septiembre, 2026
**Version**: 1.0.0
