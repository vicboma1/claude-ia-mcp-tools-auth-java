package com.laberit.hospitalslanding.service;

import com.laberit.hospitalslanding.dto.SubscriberResponse;
import com.laberit.hospitalslanding.exception.DuplicateEmailException;
import com.laberit.hospitalslanding.exception.SubscriberNotFoundException;
import com.laberit.hospitalslanding.model.Subscriber;
import com.laberit.hospitalslanding.repository.SubscriberRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Slf4j
public class SubscriberService {

    private final SubscriberRepository repository;
    private final SearchSnapshotService snapshotService;

    public SubscriberService(SubscriberRepository repository, SearchSnapshotService snapshotService) {
        this.repository = repository;
        this.snapshotService = snapshotService;
    }

    @Transactional
    public SubscriberResponse create(String email) {
        String normalized = email.trim().toLowerCase();
        if (repository.existsByEmailIgnoreCase(normalized)) {
            throw new DuplicateEmailException(normalized);
        }
        Subscriber saved = repository.save(new Subscriber(normalized));
        SubscriberResponse response = SubscriberResponse.from(saved);

        try {
            snapshotService.captureCreate("subscribers", response, "system");
        } catch (Exception e) {
            log.error("Error al capturar snapshot de creación", e);
        }

        return response;
    }

    @Transactional(readOnly = true)
    public List<SubscriberResponse> findAll() {
        List<SubscriberResponse> results = repository.findAll().stream()
                .sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()))
                .map(SubscriberResponse::from)
                .toList();

        try {
            snapshotService.captureListSearch("subscribers", results, "system");
        } catch (Exception e) {
            log.error("Error al capturar snapshot de búsqueda", e);
        }

        return results;
    }

    @Transactional
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new SubscriberNotFoundException(id);
        }
        repository.deleteById(id);

        try {
            snapshotService.captureDelete("subscribers", id, "system");
        } catch (Exception e) {
            log.error("Error al capturar snapshot de eliminación", e);
        }
    }
}
