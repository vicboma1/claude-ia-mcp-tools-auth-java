package com.laberit.hospitalslanding.controller;

import com.laberit.hospitalslanding.dto.SearchSnapshotResponse;
import com.laberit.hospitalslanding.service.SearchSnapshotService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/admin/search-snapshots")
public class SearchSnapshotController {

    private final SearchSnapshotService service;

    public SearchSnapshotController(SearchSnapshotService service) {
        this.service = service;
    }

    @GetMapping("/tab/{tab}")
    public ResponseEntity<List<SearchSnapshotResponse>> getSnapshotsByTab(@PathVariable String tab) {
        return ResponseEntity.ok(service.getSnapshotsByTab(tab).stream()
                .map(SearchSnapshotResponse::from)
                .toList());
    }

    @GetMapping("/tab/{tab}/action/{action}")
    public ResponseEntity<List<SearchSnapshotResponse>> getSnapshotsByTabAndAction(
            @PathVariable String tab,
            @PathVariable String action) {
        return ResponseEntity.ok(service.getSnapshotsByTabAndAction(tab, action).stream()
                .map(SearchSnapshotResponse::from)
                .toList());
    }

    @GetMapping("/date-range")
    public ResponseEntity<List<SearchSnapshotResponse>> getSnapshotsByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant end) {
        return ResponseEntity.ok(service.getSnapshotsByDateRange(start, end).stream()
                .map(SearchSnapshotResponse::from)
                .toList());
    }

    @GetMapping("/tab/{tab}/date-range")
    public ResponseEntity<List<SearchSnapshotResponse>> getSnapshotsByTabAndDateRange(
            @PathVariable String tab,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant end) {
        return ResponseEntity.ok(service.getSnapshotsByTabAndDateRange(tab, start, end).stream()
                .map(SearchSnapshotResponse::from)
                .toList());
    }

    @GetMapping("/tab/{tab}/count")
    public ResponseEntity<Long> getTabSnapshotCount(@PathVariable String tab) {
        return ResponseEntity.ok(service.getTabSnapshotCount(tab));
    }
}
