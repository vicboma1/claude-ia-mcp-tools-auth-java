# 🗄️ MongoDB - Sistema de Réplicas de Búsquedas

## 📌 ¿Qué es esto?

Se ha implementado un sistema automático que **captura y guarda en MongoDB todos los cambios** que realices en el panel de administración (cuando creas, borras o buscas registros).

Cada operación se guarda como un documento JSON con:
- **Qué se hizo**: CREATE, DELETE, LIST
- **Qué data se movió**: Emails, IDs, etc.
- **Cuándo pasó**: Timestamp exacto
- **Quién lo hizo**: Usuario/sistema

## 🚀 Empezar en 5 Pasos

### 1. Copiar variables de entorno
```bash
cp .env.example .env
```

### 2. Levantar MongoDB (Docker)
```bash
docker-compose -f docker-compose.mongodb.yml up -d
```

### 3. Compilar el proyecto
```bash
mvn clean install
```

### 4. Ejecutar la aplicación
```bash
mvn spring-boot:run
```

### 5. Acceder
- **Admin Panel**: http://localhost:8080/admin.html (admin/changeme)
- **MongoDB UI**: http://localhost:8081

¡Listo! Ahora cada operación en el admin genera un snapshot en MongoDB.

## 📊 Dónde Ver los Datos

### Opción 1: MongoDB UI (Web)
```
http://localhost:8081
├─ Base de datos: hospitals-snapshots
└─ Colección: search_snapshots
```

### Opción 2: API REST
```bash
# Ver todos los snapshots
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers

# Descargar como JSON
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers > snapshots.json
```

### Opción 3: mongosh (CLI)
```bash
docker exec -it hospitals-mongodb mongosh
# Dentro de MongoDB:
use hospitals-snapshots
db.search_snapshots.find().pretty()
```

## 📂 Archivos Creados

### Backend (Java)
```
src/main/java/com/laberit/hospitalslanding/
├── model/SearchSnapshot.java          ← Documento MongoDB
├── repository/SearchSnapshotRepository.java  ← Acceso a datos
├── service/SearchSnapshotService.java ← Lógica de captura
├── controller/SearchSnapshotController.java ← API REST
└── dto/SearchSnapshotResponse.java    ← Respuesta JSON
```

### Frontend
```
src/main/resources/
└── static/js/admin-snapshots.js       ← JavaScript para visualizar
```

### Configuración
```
pom.xml                          ← Dependencia MongoDB agregada
.env.example                     ← Variables de entorno
application.yml                  ← Config de MongoDB
docker-compose.mongodb.yml       ← Docker con MongoDB
mongodb-seed-data.json           ← Datos de ejemplo
```

### Documentación
```
README_MONGODB.md               ← Este archivo
QUICK_START_MONGODB.md          ← Guía rápida (paso a paso)
MONGODB_SNAPSHOTS.md            ← Documentación completa
API_EXAMPLES.md                 ← Ejemplos curl/Python
ARCHITECTURE.md                 ← Diagramas y arquitectura
IMPLEMENTATION_SUMMARY.md       ← Resumen técnico
```

## 🎯 Qué Se Captura Automáticamente

| Acción | Cuándo | Ejemplo |
|--------|--------|---------|
| **CREATE** | Nuevo email en landing | Email guardado automáticamente |
| **DELETE** | Eliminas un subscriber | ID y timestamp del borrado |
| **LIST** | Abres la pestaña de admin | Snapshot de todos los emails actuales |

## 🔍 Ejemplos Rápidos

### Ver los últimos 10 snapshots
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers | jq '.[0:10]'
```

### Contar cuántos registros se han creado
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE | jq 'length'
```

### Descargar todo como JSON
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers > mi-backup.json
```

### Ver cambios de hoy
```bash
TODAY=$(date +"%Y-%m-%dT00:00:00Z")
TOMORROW=$(date -u -d "+1 day" +"%Y-%m-%dT00:00:00Z")
curl "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/date-range?start=$TODAY&end=$TOMORROW"
```

## 🛑 Detener Todo

```bash
# Detener MongoDB
docker-compose -f docker-compose.mongodb.yml down

# Detener la aplicación
# Presiona Ctrl+C en la terminal
```

## 🐛 Si Algo Falla

### MongoDB no conecta
```bash
# Reiniciar MongoDB
docker-compose -f docker-compose.mongodb.yml restart mongodb
```

### Puerto 27017 ya está en uso
```bash
# Ver qué está usando el puerto
lsof -i :27017

# O usar otro puerto en docker-compose.mongodb.yml:
ports:
  - "27018:27017"
```

### Snapshots no aparecen
- ¿Realizaste operaciones en el admin? (crear/eliminar emails)
- ¿MongoDB está corriendo? (docker ps | grep mongodb)
- Revisa los logs: `tail -f logs/hospitals-landing.log | grep snapshot`

## 📚 Documentación Detallada

- 📖 **QUICK_START_MONGODB.md** → Instalación paso a paso
- 📖 **MONGODB_SNAPSHOTS.md** → Referencia completa (API, queries, troubleshooting)
- 📖 **API_EXAMPLES.md** → 30+ ejemplos curl/Python/Bash
- 📖 **ARCHITECTURE.md** → Diagramas, flujos, performance
- 📖 **IMPLEMENTATION_SUMMARY.md** → Resumen técnico de cambios

## 💡 Casos de Uso

✅ **Auditoría**: "¿Qué cambios se hicieron en los últimos 7 días?"
✅ **Compliance**: "Demuestra los cambios en datos sensibles"
✅ **Análisis**: "¿Cuántos emails se han suscrito?"
✅ **Debugging**: "¿Cuándo se borró este email?"
✅ **Backup**: "Descarga todos los snapshots como JSON"

## 🔄 Datos Que Se Guardan

```json
{
  "_id": "ObjectId_unico",
  "tab": "subscribers",
  "action": "CREATE",
  "results": [
    {
      "id": 1,
      "email": "usuario@example.com",
      "createdAt": "2024-09-04T10:30:00Z"
    }
  ],
  "resultCount": 1,
  "timestamp": "2024-09-04T10:30:00Z",
  "performedBy": "system",
  "details": "Nuevo registro creado"
}
```

## 🌐 Endpoints de API

```bash
GET    /api/admin/search-snapshots/tab/{tab}
GET    /api/admin/search-snapshots/tab/{tab}/action/{action}
GET    /api/admin/search-snapshots/date-range?start=...&end=...
GET    /api/admin/search-snapshots/tab/{tab}/date-range?start=...&end=...
GET    /api/admin/search-snapshots/tab/{tab}/count
```

## 🔐 Credenciales MongoDB

```env
# En .env (desarrollo local)
MONGO_HOST=localhost
MONGO_PORT=27017
MONGO_DB=hospitals-snapshots
MONGO_ADMIN_USER=admin
MONGO_ADMIN_PASSWORD=password

# En AWS Secrets Manager (producción)
Se configura en application-aws.yml
```

## 📊 Storage

```
1 snapshot ≈ 1 KB
1000 operaciones/día ≈ 1 MB/día
30 días ≈ 30 MB/mes
```

## ✨ Ventajas

- ✅ **Automático**: Sin código adicional en tus endpoints
- ✅ **No invasivo**: Errores no afectan operaciones principales
- ✅ **Flexible**: Filtrado por tab, acción, fechas
- ✅ **JSON nativo**: Fácil de procesar y exportar
- ✅ **Auditable**: Cada cambio queda registrado
- ✅ **Escalable**: MongoDB crece automáticamente

## 🚀 Próximo Nivel

### Agregar más tabs (cuando implementes nuevas módulos):
```java
// En tu servicio
snapshotService.captureCreate("hospitals", created, "system");
snapshotService.captureDelete("hospitals", id, "system");
```

### Automatizar limpieza (MongoDB):
```javascript
// Borrar snapshots con más de 90 días
db.search_snapshots.deleteMany({
  timestamp: { $lt: new Date(Date.now() - 90*24*60*60*1000) }
})
```

### Exportar para análisis (Python):
```python
import requests
snapshots = requests.get('http://localhost:8080/api/admin/search-snapshots/tab/subscribers').json()
import pandas as pd
df = pd.json_normalize(snapshots)
df.to_csv('snapshots.csv')
```

---

## 📞 ¿Necesitas Ayuda?

1. **Errores de conexión** → Ver "Si Algo Falla"
2. **¿Cómo consultar datos?** → Ver "Ejemplos Rápidos"
3. **API detallada** → Ver API_EXAMPLES.md
4. **Arquitectura** → Ver ARCHITECTURE.md
5. **Instalación** → Ver QUICK_START_MONGODB.md

---

**¡Listo para empezar!** 🎉

```bash
# Copia, ejecuta y en 2 minutos tienes snapshots funcionando:
cp .env.example .env
docker-compose -f docker-compose.mongodb.yml up -d
mvn spring-boot:run
```
