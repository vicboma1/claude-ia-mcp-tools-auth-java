package com.laberit.hospitalslanding.repository;

import com.laberit.hospitalslanding.model.SearchSnapshot;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public interface SearchSnapshotRepository extends MongoRepository<SearchSnapshot, String> {

    List<SearchSnapshot> findByTab(String tab);

    List<SearchSnapshot> findByAction(String action);

    List<SearchSnapshot> findByTabAndAction(String tab, String action);

    List<SearchSnapshot> findByTimestampBetween(Instant start, Instant end);

    @Query("{'tab': ?0, 'timestamp': {$gte: ?1, $lte: ?2}}")
    List<SearchSnapshot> findByTabAndDateRange(String tab, Instant start, Instant end);

    List<SearchSnapshot> findByPerformedBy(String performedBy);

    long countByTab(String tab);
}
