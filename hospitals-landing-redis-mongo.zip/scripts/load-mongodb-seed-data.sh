#!/bin/bash

# Script para cargar datos de ejemplo en MongoDB
# Uso: ./scripts/load-mongodb-seed-data.sh

set -e

# Colores para output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Variables por defecto (se pueden sobrescribir con env vars)
MONGO_HOST=${MONGO_HOST:-localhost}
MONGO_PORT=${MONGO_PORT:-27017}
MONGO_DB=${MONGO_DB:-hospitals-snapshots}
MONGO_ADMIN_USER=${MONGO_ADMIN_USER:-admin}
MONGO_ADMIN_PASSWORD=${MONGO_ADMIN_PASSWORD:-password}
SEED_FILE="./mongodb-seed-data.json"

echo -e "${YELLOW}🚀 Cargando datos de ejemplo en MongoDB...${NC}"
echo "Host: $MONGO_HOST:$MONGO_PORT"
echo "Base de datos: $MONGO_DB"

# Verificar que el archivo de datos existe
if [ ! -f "$SEED_FILE" ]; then
    echo -e "${RED}❌ Error: Archivo $SEED_FILE no encontrado${NC}"
    exit 1
fi

# Verificar que MongoDB está corriendo
echo -e "${YELLOW}⏳ Verificando conexión a MongoDB...${NC}"
if ! mongosh \
    --host "$MONGO_HOST:$MONGO_PORT" \
    -u "$MONGO_ADMIN_USER" \
    -p "$MONGO_ADMIN_PASSWORD" \
    --authenticationDatabase admin \
    --quiet \
    --eval "print('OK')" 2>/dev/null; then
    echo -e "${RED}❌ Error: No se puede conectar a MongoDB en $MONGO_HOST:$MONGO_PORT${NC}"
    echo "Asegúrate de que MongoDB está corriendo:"
    echo "  docker-compose -f docker-compose.mongodb.yml up -d"
    exit 1
fi

echo -e "${GREEN}✅ Conexión exitosa${NC}"

# Cargar los datos
echo -e "${YELLOW}📥 Importando colección search_snapshots...${NC}"

mongoimport \
    --host "$MONGO_HOST:$MONGO_PORT" \
    -u "$MONGO_ADMIN_USER" \
    -p "$MONGO_ADMIN_PASSWORD" \
    --authenticationDatabase admin \
    -d "$MONGO_DB" \
    -c search_snapshots \
    --jsonArray \
    --file "$SEED_FILE" \
    --drop

echo -e "${GREEN}✅ Datos importados exitosamente${NC}"

# Mostrar resumen
echo -e "\n${YELLOW}📊 Resumen de datos cargados:${NC}"
mongosh \
    --host "$MONGO_HOST:$MONGO_PORT" \
    -u "$MONGO_ADMIN_USER" \
    -p "$MONGO_ADMIN_PASSWORD" \
    --authenticationDatabase admin \
    "$MONGO_DB" \
    --quiet \
    --eval "
        const count = db.search_snapshots.countDocuments();
        const createCount = db.search_snapshots.countDocuments({action: 'CREATE'});
        const deleteCount = db.search_snapshots.countDocuments({action: 'DELETE'});
        const listCount = db.search_snapshots.countDocuments({action: 'LIST'});

        console.log('Total de snapshots: ' + count);
        console.log('CREATE: ' + createCount);
        console.log('DELETE: ' + deleteCount);
        console.log('LIST: ' + listCount);
    "

echo -e "\n${GREEN}✨ ¡Listo! Accede a http://localhost:8081 para ver los datos en Mongo Express${NC}"
