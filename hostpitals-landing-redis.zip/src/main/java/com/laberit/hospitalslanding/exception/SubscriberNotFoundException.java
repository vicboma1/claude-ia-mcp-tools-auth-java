package com.laberit.hospitalslanding.exception;

public class SubscriberNotFoundException extends RuntimeException {

    public SubscriberNotFoundException(Long id) {
        super("No existe un suscriptor con id " + id);
    }
}
