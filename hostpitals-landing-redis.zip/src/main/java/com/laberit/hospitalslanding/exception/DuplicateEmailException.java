package com.laberit.hospitalslanding.exception;

public class DuplicateEmailException extends RuntimeException {

    public DuplicateEmailException(String email) {
        super("El correo '" + email + "' ya está registrado");
    }
}
