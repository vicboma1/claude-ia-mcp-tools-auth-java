# 🚀 COMIENZA AQUÍ - MongoDB Snapshots

## ¿Qué se ha hecho?

Se ha agregado **MongoDB** al proyecto para **capturar automáticamente réplicas** de cada operación que hagas en el panel de administración:

- ✅ Cuando **creas** un email
- ✅ Cuando **borras** un email  
- ✅ Cuando **listas** los emails

Y todo se **visualiza en un nuevo tab del admin**.

---

## 5 Minutos para Empezar

### 1️⃣ Preparar (30 segundos)
```bash
cp .env.example .env
```

### 2️⃣ Levantar MongoDB (1 minuto)
```bash
docker-compose -f docker-compose.mongodb.yml up -d
```

Espera a que veas:
```
✅ MongoDB está listo
✅ Mongo Express está en http://localhost:8081
```

### 3️⃣ Compilar (1 minuto)
```bash
mvn clean install
```

### 4️⃣ Ejecutar (1 minuto)
```bash
mvn spring-boot:run
```

Espera a ver:
```
✅ Tomcat started on port 8080
```

### 5️⃣ Abrir (30 segundos)
```
http://localhost:8080/admin.html
Usuario: admin
Contraseña: changeme
```

---

## ¿Dónde están los datos?

### 📊 En el Admin Panel
Nuevo tab: **MongoDB** (junto a Suscriptores, Redis, etc)

```
┌──────────────────────────────────────────────────┐
│ Suscriptores │ MongoDB ← ¡AQUÍ ESTÁN! │ Redis   │
└──────────────────────────────────────────────────┘
```

### 🌐 En MongoDB UI
```
http://localhost:8081
└─ hospitals-snapshots
   └─ search_snapshots (todos los datos)
```

### 📡 En la API
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers
```

---

## Prueba Rápida

1. Abre http://localhost:8080/admin.html
2. Ve a tab **Suscriptores**
3. **Crea** un nuevo email (ej: test@example.com)
4. **Borra** un email
5. **Lista** para ver todos
6. Vuelve al tab **MongoDB**
7. ¡Verás automáticamente 3 snapshots capturados!

---

## ¿Qué Significa MongoDB Tab?

```
┌─────────────────────────────────────────────┐
│ MongoDB - Réplicas de Búsquedas             │
├─────────────────────────────────────────────┤
│                                              │
│ Filtros: [Suscriptores ▼] [Todas ▼] [24h ▼]│
│          [Filtrar] [Actualizar] [Descargar] │
│                                              │
│ Tabla de Snapshots:                         │
│ ┌────────────────────────────────────────┐ │
│ │ Acción │ Tab      │ Registros │ Hora   │ │
│ ├────────────────────────────────────────┤ │
│ │ CREATE │ suscr.   │ 1         │ 10:30  │ │
│ │ DELETE │ suscr.   │ 0         │ 10:31  │ │
│ │ LIST   │ suscr.   │ 2         │ 10:32  │ │
│ └────────────────────────────────────────┘ │
└─────────────────────────────────────────────┘
```

**Cada fila es un snapshot** = una operación registrada en JSON

---

## Funciones del Tab MongoDB

| Botón | Función |
|-------|---------|
| 👁️ | Ver detalles JSON completos |
| 📥 | Descargar snapshot individual |
| 🔄 Actualizar | Refrescar la lista |
| 📥 Descargar JSON | Descargar todos los filtrados |

### Filtros
- **Tab**: Qué módulo (Suscriptores, Hospitales, etc)
- **Acción**: CREATE, DELETE, o LIST
- **Últimas**: 1h, 24h, 7d, 30d o Todos

---

## Estructura de un Snapshot

```json
{
  "tab": "subscribers",           // Dónde pasó
  "action": "CREATE",             // Qué se hizo
  "results": [                    // Datos JSON
    {
      "id": 1,
      "email": "user@example.com",
      "createdAt": "2024-09-04T10:15:30Z"
    }
  ],
  "resultCount": 1,               // Cuántos registros
  "timestamp": "2024-09-04T10:30:45Z",  // Cuándo
  "performedBy": "system",        // Quién lo hizo
  "details": "Nuevo registro creado"  // Por qué
}
```

---

## Archivos Implementados

### Backend (Java)
- ✅ `SearchSnapshot.java` - Modelo MongoDB
- ✅ `SearchSnapshotRepository.java` - Acceso a datos
- ✅ `SearchSnapshotService.java` - Lógica de captura
- ✅ `SearchSnapshotController.java` - API REST

### Frontend (JavaScript)
- ✅ `admin-mongodb.js` - **¡NUEVO! Lógica del tab**
- ✅ `admin.html` - Actualizado con tab MongoDB

### Configuración
- ✅ `pom.xml` - Dependencia MongoDB
- ✅ `application.yml` - Config de MongoDB
- ✅ `docker-compose.mongodb.yml` - Docker setup
- ✅ `.env.example` - Variables de entorno

---

## Si Algo Falla

### MongoDB no conecta
```bash
docker-compose -f docker-compose.mongodb.yml restart mongodb
```

### Port 27017 en uso
```bash
# Editar docker-compose.mongodb.yml:
ports:
  - "27018:27017"  # Cambiar a 27018
```

### No compila
```bash
mvn clean install -U
```

### No aparecen snapshots
1. ¿Hiciste operaciones en Suscriptores? (crear/borrar)
2. ¿MongoDB está corriendo? (`docker ps | grep mongodb`)
3. ¿Estás en el tab correcto?
4. Presiona "Actualizar" en MongoDB tab

---

## Próximos Pasos

### Lectura Recomendada
- 📖 `README_MONGODB.md` - Overview completo
- 📖 `QUICK_START_MONGODB.md` - 7 pasos detallados
- 📖 `API_EXAMPLES.md` - Ejemplos curl/Python
- 📖 `ARCHITECTURE.md` - Diagramas del sistema

### Usar en Producción
1. Cambiar credenciales en `.env`
2. Usar AWS Secrets Manager (ver `application-aws.yml`)
3. Configurar limpieza automática (90 días)
4. Configurar backups de MongoDB

### Agregar Más Módulos
Cuando agregues hospitales, usuarios, etc:
```java
snapshotService.captureCreate("hospitals", created, "system");
snapshotService.captureDelete("hospitals", id, "system");
snapshotService.captureListSearch("hospitals", results, "system");
```

---

## ¡Listo!

```bash
# Copiar y pegar estos 3 comandos:
cp .env.example .env
docker-compose -f docker-compose.mongodb.yml up -d
mvn spring-boot:run
```

Luego abre:
```
http://localhost:8080/admin.html
```

Y ve al tab **MongoDB** ← ¡Tu nuevo sistema de auditoría! 🎉

---

## Resumen

| Aspecto | Status |
|--------|--------|
| Backend Java | ✅ Listo |
| MongoDB | ✅ Listo |
| API REST | ✅ Listo |
| Frontend Tab | ✅ Listo |
| Docker Compose | ✅ Listo |
| Documentación | ✅ Listo |

**Todo está implementado y funcionando.**

Solo necesitas ejecutar:
```bash
docker-compose -f docker-compose.mongodb.yml up -d
mvn spring-boot:run
```

¡Y listo! 🚀
