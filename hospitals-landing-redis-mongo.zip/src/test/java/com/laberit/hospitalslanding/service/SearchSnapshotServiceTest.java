package com.laberit.hospitalslanding.service;

import com.laberit.hospitalslanding.dto.SubscriberResponse;
import com.laberit.hospitalslanding.model.SearchSnapshot;
import com.laberit.hospitalslanding.repository.SearchSnapshotRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SearchSnapshotServiceTest {

    @Mock
    private SearchSnapshotRepository repository;

    @InjectMocks
    private SearchSnapshotService service;

    private SearchSnapshot testSnapshot;
    private SubscriberResponse testSubscriber;

    @BeforeEach
    void setUp() {
        testSubscriber = new SubscriberResponse(1L, "test@example.com", Instant.now());
        testSnapshot = SearchSnapshot.builder()
                .tab("subscribers")
                .action("CREATE")
                .results(List.of(Map.of("id", 1, "email", "test@example.com")))
                .resultCount(1)
                .timestamp(Instant.now())
                .performedBy("system")
                .details("Test snapshot")
                .build();
    }

    @Test
    void testCaptureSearchSnapshot() {
        // Arrange
        when(repository.save(any(SearchSnapshot.class))).thenReturn(testSnapshot);

        // Act
        SearchSnapshot result = service.captureSearchSnapshot(
                "subscribers",
                "CREATE",
                List.of(testSubscriber),
                "system",
                "Test snapshot"
        );

        // Assert
        assertNotNull(result);
        assertEquals("subscribers", result.getTab());
        assertEquals("CREATE", result.getAction());
        assertEquals(1, result.getResultCount());
        assertEquals("system", result.getPerformedBy());
        assertEquals("Test snapshot", result.getDetails());
        verify(repository, times(1)).save(any(SearchSnapshot.class));
    }

    @Test
    void testCaptureCreate() {
        // Arrange
        when(repository.save(any(SearchSnapshot.class))).thenReturn(testSnapshot);

        // Act
        service.captureCreate("subscribers", testSubscriber, "admin");

        // Assert
        verify(repository, times(1)).save(any(SearchSnapshot.class));
    }

    @Test
    void testCaptureDelete() {
        // Arrange
        when(repository.save(any(SearchSnapshot.class))).thenReturn(testSnapshot);

        // Act
        service.captureDelete("subscribers", 1L, "admin");

        // Assert
        verify(repository, times(1)).save(any(SearchSnapshot.class));
    }

    @Test
    void testCaptureListSearch() {
        // Arrange
        List<SubscriberResponse> results = new ArrayList<>();
        results.add(testSubscriber);
        when(repository.save(any(SearchSnapshot.class))).thenReturn(testSnapshot);

        // Act
        service.captureListSearch("subscribers", results, "admin");

        // Assert
        verify(repository, times(1)).save(any(SearchSnapshot.class));
    }

    @Test
    void testGetSnapshotsByTab() {
        // Arrange
        List<SearchSnapshot> snapshots = List.of(testSnapshot);
        when(repository.findByTab("subscribers")).thenReturn(snapshots);

        // Act
        List<SearchSnapshot> result = service.getSnapshotsByTab("subscribers");

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("subscribers", result.get(0).getTab());
        verify(repository, times(1)).findByTab("subscribers");
    }

    @Test
    void testGetSnapshotsByTabAndAction() {
        // Arrange
        List<SearchSnapshot> snapshots = List.of(testSnapshot);
        when(repository.findByTabAndAction("subscribers", "CREATE")).thenReturn(snapshots);

        // Act
        List<SearchSnapshot> result = service.getSnapshotsByTabAndAction("subscribers", "CREATE");

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("CREATE", result.get(0).getAction());
        verify(repository, times(1)).findByTabAndAction("subscribers", "CREATE");
    }

    @Test
    void testGetSnapshotsByDateRange() {
        // Arrange
        Instant start = Instant.now().minusSeconds(3600);
        Instant end = Instant.now();
        List<SearchSnapshot> snapshots = List.of(testSnapshot);
        when(repository.findByTimestampBetween(start, end)).thenReturn(snapshots);

        // Act
        List<SearchSnapshot> result = service.getSnapshotsByDateRange(start, end);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(repository, times(1)).findByTimestampBetween(start, end);
    }

    @Test
    void testGetTabSnapshotCount() {
        // Arrange
        when(repository.countByTab("subscribers")).thenReturn(5L);

        // Act
        long result = service.getTabSnapshotCount("subscribers");

        // Assert
        assertEquals(5L, result);
        verify(repository, times(1)).countByTab("subscribers");
    }

    @Test
    void testCaptureWithEmptyResults() {
        // Arrange
        SearchSnapshot emptySnapshot = SearchSnapshot.builder()
                .tab("subscribers")
                .action("DELETE")
                .results(new ArrayList<>())
                .resultCount(0)
                .timestamp(Instant.now())
                .performedBy("system")
                .details("Deleted ID: 1")
                .build();
        when(repository.save(any(SearchSnapshot.class))).thenReturn(emptySnapshot);

        // Act
        SearchSnapshot result = service.captureSearchSnapshot(
                "subscribers",
                "DELETE",
                new ArrayList<>(),
                "system",
                "Deleted ID: 1"
        );

        // Assert
        assertNotNull(result);
        assertEquals(0, result.getResultCount());
        verify(repository, times(1)).save(any(SearchSnapshot.class));
    }

    @Test
    void testConvertSubscriberResponseToMap() {
        // Arrange
        List<SubscriberResponse> responses = List.of(testSubscriber);
        SearchSnapshot listSnapshot = SearchSnapshot.builder()
                .tab("subscribers")
                .action("LIST")
                .results(List.of(Map.of("id", 1, "email", "test@example.com")))
                .resultCount(1)
                .timestamp(Instant.now())
                .performedBy("system")
                .details("List all")
                .build();
        when(repository.save(any(SearchSnapshot.class))).thenReturn(listSnapshot);

        // Act
        SearchSnapshot result = service.captureSearchSnapshot(
                "subscribers",
                "LIST",
                responses,
                "system",
                "List all"
        );

        // Assert
        assertNotNull(result);
        assertEquals("subscribers", result.getTab());
        assertEquals("LIST", result.getAction());
        verify(repository, times(1)).save(any(SearchSnapshot.class));
    }
}
