package com.laberit.hospitalslanding.controller;

import com.laberit.hospitalslanding.dto.SubscriberRequest;
import com.laberit.hospitalslanding.dto.SubscriberResponse;
import com.laberit.hospitalslanding.service.SubscriberService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * CRUD de correos capturados en la landing:
 *  - POST   /api/subscribers      -> crear (público, lo usa el formulario de la landing)
 *  - GET    /api/subscribers      -> listar (requiere autenticación de administrador)
 *  - DELETE /api/subscribers/{id} -> eliminar (requiere autenticación de administrador)
 */
@RestController
@RequestMapping("/api/subscribers")
public class SubscriberController {

    private final SubscriberService service;

    public SubscriberController(SubscriberService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<SubscriberResponse> create(@Valid @RequestBody SubscriberRequest request) {
        SubscriberResponse created = service.create(request.getEmail());
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<SubscriberResponse>> list() {
        return ResponseEntity.ok(service.findAll());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
