package com.laberit.hospitalslanding.controller;

import com.laberit.hospitalslanding.dto.EnvironmentVariableResponse;
import com.laberit.hospitalslanding.service.EnvironmentVariablesService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/environment")
public class EnvironmentVariablesController {

    private final EnvironmentVariablesService environmentVariablesService;

    public EnvironmentVariablesController(EnvironmentVariablesService environmentVariablesService) {
        this.environmentVariablesService = environmentVariablesService;
    }

    @GetMapping("/all")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<EnvironmentVariableResponse>> getAllEnvironmentVariables() {
        return ResponseEntity.ok(environmentVariablesService.getAllEnvironmentVariables());
    }

    @GetMapping("/{key}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<EnvironmentVariableResponse> getEnvironmentVariable(@PathVariable String key) {
        EnvironmentVariableResponse variable = environmentVariablesService.getEnvironmentVariable(key);
        if (variable == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(variable);
    }

    @GetMapping("/search")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<EnvironmentVariableResponse>> searchEnvironmentVariables(
            @RequestParam(required = false) String query) {
        return ResponseEntity.ok(environmentVariablesService.filterEnvironmentVariables(query));
    }

    @GetMapping("/count")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Map<String, Long>> countEnvironmentVariables() {
        Map<String, Long> response = new HashMap<>();
        response.put("count", environmentVariablesService.countEnvironmentVariables());
        return ResponseEntity.ok(response);
    }
}
