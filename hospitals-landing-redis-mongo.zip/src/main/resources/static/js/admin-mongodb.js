document.addEventListener('DOMContentLoaded', function() {
    const API_BASE = '/api/admin/search-snapshots';
    let allSnapshots = [];
    let filteredSnapshots = [];

    const tabFilter = document.getElementById('mongodb-tab-filter');
    const actionFilter = document.getElementById('mongodb-action-filter');
    const timerangeFilter = document.getElementById('mongodb-timerange-filter');
    const filterBtn = document.getElementById('mongodb-filter-btn');
    const refreshBtn = document.getElementById('mongodb-refresh-btn');
    const downloadBtn = document.getElementById('mongodb-download-btn');
    const countLabel = document.getElementById('mongodb-count-label');
    const tableBody = document.getElementById('mongodb-snapshots-body');
    const messageDiv = document.getElementById('mongodb-message');

    function formatDate(timestamp) {
        return new Date(timestamp).toLocaleString('es-ES', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }

    function getActionBadge(action) {
        const colors = {
            'CREATE': '#28a745',
            'DELETE': '#dc3545',
            'LIST': '#0066cc'
        };
        return `<span style="background: ${colors[action] || '#999'}; color: white; padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 0.85rem; font-weight: 600;">${action}</span>`;
    }

    function renderSnapshots(snapshots) {
        if (!snapshots || snapshots.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #999;">No hay snapshots disponibles</td></tr>';
            countLabel.textContent = 'Total: 0';
            return;
        }

        tableBody.innerHTML = snapshots.map((snapshot, index) => `
            <tr>
                <td>${getActionBadge(snapshot.action)}</td>
                <td><strong>${snapshot.tab || 'N/A'}</strong></td>
                <td style="text-align: center;">
                    <span style="background: #f0f0f0; padding: 0.25rem 0.75rem; border-radius: 4px; font-size: 0.9rem;">
                        ${snapshot.resultCount || 0}
                    </span>
                </td>
                <td style="font-size: 0.9rem; color: #666;">${formatDate(snapshot.timestamp)}</td>
                <td style="font-size: 0.9rem; color: #666;">${snapshot.details || '-'}</td>
                <td>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn btn-small" onclick="window.MongoDBAdmin.toggleDetails('${index}')" title="Ver detalles">👁️</button>
                        <button class="btn btn-small" onclick="window.MongoDBAdmin.downloadSnapshot('${index}')" title="Descargar JSON">📥</button>
                    </div>
                </td>
            </tr>
            <tr id="details-${index}" style="display: none;">
                <td colspan="6" style="padding: 1.5rem; background: #f9f9f9;">
                    <div style="max-height: 400px; overflow-y: auto;">
                        <details>
                            <summary style="cursor: pointer; margin-bottom: 1rem; font-weight: 600;">Datos Capturados</summary>
                            <pre style="background: #f0f0f0; padding: 1rem; border-radius: 4px; font-size: 0.85rem; overflow-x: auto;">${JSON.stringify(snapshot.results || [], null, 2)}</pre>
                        </details>
                        <details>
                            <summary style="cursor: pointer; margin-bottom: 1rem; font-weight: 600;">Información Completa</summary>
                            <pre style="background: #f0f0f0; padding: 1rem; border-radius: 4px; font-size: 0.85rem; overflow-x: auto;">${JSON.stringify(snapshot, null, 2)}</pre>
                        </details>
                    </div>
                </td>
            </tr>
        `).join('');

        countLabel.textContent = `Total: ${snapshots.length}`;
    }

    function getTimeRangeFilter() {
        const now = new Date();
        const range = timerangeFilter.value;
        let start = new Date(0);

        switch(range) {
            case '1hour':
                start = new Date(now.getTime() - 60 * 60 * 1000);
                break;
            case '24hours':
                start = new Date(now.getTime() - 24 * 60 * 60 * 1000);
                break;
            case '7days':
                start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                break;
            case '30days':
                start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                break;
        }

        return { start, end: now };
    }

    async function loadSnapshots() {
        try {
            showMessage('⏳ Cargando snapshots...', 'info');

            const tab = tabFilter.value;
            const action = actionFilter.value;
            const { start, end } = getTimeRangeFilter();

            let url;
            if (tab && action) {
                url = `${API_BASE}/tab/${tab}/action/${action}`;
            } else if (tab) {
                if (timerangeFilter.value !== 'all') {
                    url = `${API_BASE}/tab/${tab}/date-range?start=${start.toISOString()}&end=${end.toISOString()}`;
                } else {
                    url = `${API_BASE}/tab/${tab}`;
                }
            } else if (action) {
                url = `${API_BASE}/tab/subscribers/action/${action}`;
            } else {
                if (timerangeFilter.value !== 'all') {
                    url = `${API_BASE}/date-range?start=${start.toISOString()}&end=${end.toISOString()}`;
                } else {
                    url = `${API_BASE}/tab/subscribers`;
                }
            }

            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`Error: ${response.status}`);
            }

            allSnapshots = await response.json();
            filteredSnapshots = allSnapshots;
            renderSnapshots(filteredSnapshots);
            showMessage('✅ Snapshots cargados exitosamente', 'success');
        } catch (error) {
            console.error('Error loading snapshots:', error);
            showMessage(`❌ Error al cargar: ${error.message}`, 'error');
            tableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #d32f2f;">Error al cargar snapshots</td></tr>';
        }
    }

    function showMessage(text, type) {
        messageDiv.textContent = text;
        messageDiv.style.display = 'block';
        messageDiv.className = `form-message form-message-${type}`;

        if (type === 'success' || type === 'info') {
            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 5000);
        }
    }

    window.MongoDBAdmin = {
        toggleDetails(index) {
            const detailsRow = document.getElementById(`details-${index}`);
            if (detailsRow) {
                detailsRow.style.display = detailsRow.style.display === 'none' ? 'table-row' : 'none';
            }
        },

        downloadSnapshot(index) {
            const snapshot = filteredSnapshots[index];
            if (!snapshot) return;

            const filename = `snapshot-${snapshot.tab}-${snapshot.action}-${new Date(snapshot.timestamp).getTime()}.json`;
            const json = JSON.stringify(snapshot, null, 2);
            const blob = new Blob([json], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            showMessage(`✅ Descargado: ${filename}`, 'success');
        },

        downloadAll() {
            if (filteredSnapshots.length === 0) {
                showMessage('❌ No hay snapshots para descargar', 'error');
                return;
            }

            const now = new Date();
            const filename = `snapshots-${now.getTime()}.json`;
            const json = JSON.stringify(filteredSnapshots, null, 2);
            const blob = new Blob([json], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            showMessage(`✅ Descargados ${filteredSnapshots.length} snapshots en ${filename}`, 'success');
        }
    };

    // Event Listeners
    filterBtn.addEventListener('click', loadSnapshots);
    refreshBtn.addEventListener('click', loadSnapshots);
    downloadBtn.addEventListener('click', () => window.MongoDBAdmin.downloadAll());

    // Cargar snapshots al abrir la tab
    const mongodbTab = document.getElementById('mongodb');
    if (mongodbTab) {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mongodbTab.classList.contains('active') && !allSnapshots.length) {
                    loadSnapshots();
                }
            });
        });

        observer.observe(mongodbTab, { attributes: true, attributeFilter: ['class'] });
    }

    // Cargar datos iniciales si el tab ya estaba activo
    if (mongodbTab && mongodbTab.classList.contains('active')) {
        loadSnapshots();
    }
});
