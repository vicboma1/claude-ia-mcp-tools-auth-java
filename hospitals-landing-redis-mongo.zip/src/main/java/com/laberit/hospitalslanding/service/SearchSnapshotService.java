package com.laberit.hospitalslanding.service;

import com.laberit.hospitalslanding.dto.SubscriberResponse;
import com.laberit.hospitalslanding.model.SearchSnapshot;
import com.laberit.hospitalslanding.repository.SearchSnapshotRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SearchSnapshotService {

    private final SearchSnapshotRepository repository;

    public SearchSnapshotService(SearchSnapshotRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public SearchSnapshot captureSearchSnapshot(String tab, String action, List<?> results, String performedBy, String details) {
        List<Map<String, Object>> resultsList = convertResults(results);

        SearchSnapshot snapshot = SearchSnapshot.builder()
                .tab(tab)
                .action(action)
                .results(resultsList)
                .resultCount(resultsList.size())
                .timestamp(Instant.now())
                .performedBy(performedBy)
                .details(details)
                .build();

        return repository.save(snapshot);
    }

    @Transactional
    public void captureListSearch(String tab, List<SubscriberResponse> results, String performedBy) {
        captureSearchSnapshot(tab, "LIST", results, performedBy, "Búsqueda/listado general");
    }

    @Transactional
    public void captureCreate(String tab, SubscriberResponse created, String performedBy) {
        captureSearchSnapshot(tab, "CREATE", List.of(created), performedBy, "Nuevo registro creado");
    }

    @Transactional
    public void captureDelete(String tab, Long deletedId, String performedBy) {
        captureSearchSnapshot(tab, "DELETE", List.of(), performedBy, "Registro eliminado - ID: " + deletedId);
    }

    @Transactional(readOnly = true)
    public List<SearchSnapshot> getSnapshotsByTab(String tab) {
        return repository.findByTab(tab);
    }

    @Transactional(readOnly = true)
    public List<SearchSnapshot> getSnapshotsByTabAndAction(String tab, String action) {
        return repository.findByTabAndAction(tab, action);
    }

    @Transactional(readOnly = true)
    public List<SearchSnapshot> getSnapshotsByDateRange(Instant start, Instant end) {
        return repository.findByTimestampBetween(start, end);
    }

    @Transactional(readOnly = true)
    public List<SearchSnapshot> getSnapshotsByTabAndDateRange(String tab, Instant start, Instant end) {
        return repository.findByTabAndDateRange(tab, start, end);
    }

    @Transactional(readOnly = true)
    public long getTabSnapshotCount(String tab) {
        return repository.countByTab(tab);
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> convertResults(List<?> results) {
        List<Map<String, Object>> resultsList = new ArrayList<>();

        for (Object result : results) {
            if (result instanceof Map) {
                resultsList.add((Map<String, Object>) result);
            } else if (result instanceof SubscriberResponse) {
                SubscriberResponse sr = (SubscriberResponse) result;
                Map<String, Object> map = new HashMap<>();
                map.put("id", sr.getId());
                map.put("email", sr.getEmail());
                map.put("createdAt", sr.getCreatedAt());
                resultsList.add(map);
            } else {
                resultsList.add(new HashMap<>());
            }
        }

        return resultsList;
    }
}
