package com.laberit.hospitalslanding.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Document(collection = "search_snapshots")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SearchSnapshot {

    @Id
    private String id;

    private String tab;

    private String action;

    private List<Map<String, Object>> results;

    private Integer resultCount;

    private Instant timestamp;

    private String performedBy;

    private String details;
}
