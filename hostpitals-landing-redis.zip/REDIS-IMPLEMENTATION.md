# Redis Implementation - Hospitals Landing

## ✅ Implementación Completada

Se ha integrado exitosamente **Redis** en el proyecto con control de administración desde un panel de API REST.

### 📦 **Cambios Realizados**

#### 1. **Dependencias Maven** (pom.xml)
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
<dependency>
    <groupId>redis.clients</groupId>
    <artifactId>jedis</artifactId>
</dependency>
```

#### 2. **Docker Compose** (docker-compose.yml)
- ✅ Servicio Redis 7-alpine con puerto 6379
- ✅ Volumen persistente: `redis_data`
- ✅ Health check automático
- ✅ Dependencia en la app: espera a que Redis esté healthy

#### 3. **Configuración Spring** (application.yml)
```yaml
spring.data.redis:
  host: ${REDIS_HOST:localhost}
  port: ${REDIS_PORT:6379}
  timeout: 60000
  jedis:
    pool:
      max-active: 8
      max-idle: 8
      min-idle: 0

app.redis:
  enabled: ${REDIS_ENABLED:true}
  ttl: ${REDIS_TTL:0}
  max-connections: ${REDIS_MAX_CONNECTIONS:8}
  min-idle-connections: ${REDIS_MIN_IDLE_CONNECTIONS:0}
```

#### 4. **Configuraciones Java**
- `RedisConfig.java`: Bean configuration para RedisTemplate
- `RedisProperties.java`: Propiedades externalizadas (@ConfigurationProperties)
- `SecurityConfig.java`: Configuración de Spring Security con @EnableMethodSecurity

#### 5. **Servicio de Redis** (RedisService.java)
Métodos disponibles:
- `set(key, value)` - Guardar un valor
- `get(key)` - Obtener un valor
- `delete(key)` - Eliminar una clave
- `exists(key)` - Verificar si existe una clave
- `update(key, value)` - Actualizar un valor existente
- `getAllKeyValues()` - Obtener todos los key-value como lista

#### 6. **API REST Admin** (AdminRedisController.java)
Endpoints protegidos con autenticación básica:

| Método | Endpoint | Autenticación | Descripción |
|--------|----------|---------------|-------------|
| GET | `/api/admin/redis/ping` | No | Health check |
| GET | `/api/admin/redis/all` | Sí (ADMIN) | Listar todos |
| GET | `/api/admin/redis/{key}` | Sí (ADMIN) | Obtener un valor |
| POST | `/api/admin/redis` | Sí (ADMIN) | Crear novo key-value |
| PUT | `/api/admin/redis/{key}` | Sí (ADMIN) | Actualizar valor |
| DELETE | `/api/admin/redis/{key}` | Sí (ADMIN) | Eliminar |

#### 7. **DTOs**
- `RedisKeyValueRequest.java` - Request para POST/PUT
- `RedisKeyValueResponse.java` - Response con key y value

### 🚀 **Cómo Usar**

#### 1. **Iniciar el stack**
```bash
docker-compose up -d
```

#### 2. **Crear un key-value**
```bash
curl -X POST http://localhost:8080/api/admin/redis \
  -H "Content-Type: application/json" \
  -u admin:changeme \
  -d '{
    "key": "config-db",
    "value": "prod-server-01"
  }'
```

#### 3. **Listar todos los key-values**
```bash
curl http://localhost:8080/api/admin/redis/all \
  -u admin:changeme
```

#### 4. **Obtener un value específico**
```bash
curl http://localhost:8080/api/admin/redis/config-db \
  -u admin:changeme
```

#### 5. **Actualizar un value**
```bash
curl -X PUT http://localhost:8080/api/admin/redis/config-db \
  -H "Content-Type: application/json" \
  -u admin:changeme \
  -d '{"value": "prod-server-02"}'
```

#### 6. **Eliminar un key-value**
```bash
curl -X DELETE http://localhost:8080/api/admin/redis/config-db \
  -u admin:changeme
```

### 🔐 **Credenciales por Defecto**
- Usuario: `admin`
- Contraseña: `changeme`

Cambiar via variables de entorno:
```bash
ADMIN_USER=tu_usuario
ADMIN_PASSWORD=tu_contraseña
```

### 📊 **Variables de Entorno Configurables**

| Variable | Descripción | Default |
|----------|-------------|---------|
| `REDIS_HOST` | Host de Redis | redis (en Docker) |
| `REDIS_PORT` | Puerto de Redis | 6379 |
| `REDIS_ENABLED` | Habilitar Redis | true |
| `REDIS_TTL` | TTL por defecto (segundos) | 0 (sin expiración) |
| `REDIS_MAX_CONNECTIONS` | Máximo de conexiones | 8 |
| `REDIS_MIN_IDLE_CONNECTIONS` | Conexiones mínimas idle | 0 |

### 🔍 **Validación de Build**

```
✅ Maven clean compile test package: EXITOSO
✅ Docker build: EXITOSO
✅ Imagen creada: hospitals-landing:latest
✅ Todos los contenedores corriendo
```

### 📁 **Archivos Creados/Modificados**

**Nuevos archivos:**
```
src/main/java/com/laberit/hospitalslanding/
├── config/
│   ├── RedisConfig.java
│   └── RedisProperties.java
├── controller/
│   └── AdminRedisController.java
├── dto/
│   ├── RedisKeyValueRequest.java
│   └── RedisKeyValueResponse.java
└── service/
    └── RedisService.java
```

**Archivos modificados:**
```
pom.xml (+ Redis dependencies)
docker-compose.yml (+ Redis service)
src/main/resources/application.yml (+ Redis config)
src/main/java/com/laberit/hospitalslanding/config/SecurityConfig.java
src/main/java/com/laberit/hospitalslanding/Dockerfile (sin cambios)
```

### 💡 **Notas Importantes**

1. **Seguridad**: Todos los endpoints de admin requieren autenticación HTTP Basic con rol ADMIN
2. **Serialización**: Se usa StringRedisSerializer para keys y values (tipo String)
3. **Persistencia**: Redis guarda datos en volumen `redis_data` de Docker
4. **Health Checks**: Ambos servicios (DB y Redis) tienen health checks configurados
5. **Configuración Externalizada**: Todas las propiedades pueden configurarse via variables de entorno

### 🔄 **Integración con Aplicación Existente**

El controlador de Redis es completamente independiente de la funcionalidad existente de suscriptores. Se puede usar para:
- Guardar configuraciones dinámicas
- Cachear datos
- Almacenar claves de API
- Guardar settings de la aplicación
- Implementar rate limiting

### 📝 **Próximos Pasos Recomendados**

1. Crear un frontend web para gestionar Redis keys-values
2. Implementar TTL (Time To Live) para claves
3. Agregar tipos de datos adicionales (hashes, listas, sets)
4. Implementar paginación en el listado de keys
5. Agregar búsqueda por patrón de keys
6. Implementar monitoreo de Redis en el dashboard admin

---

**Fecha de Implementación**: 2 de Septiembre, 2026
**Versión**: 1.0.0
**Stack**: Spring Boot 3.3.4 + Redis 7 + Docker
