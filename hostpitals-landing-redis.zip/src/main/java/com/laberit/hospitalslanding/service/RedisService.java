package com.laberit.hospitalslanding.service;

import com.laberit.hospitalslanding.dto.RedisKeyValueResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RedisService {

    private final RedisTemplate<String, String> redisTemplate;

    public void set(String key, String value) {
        redisTemplate.opsForValue().set(key, value);
    }

    public String get(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    public void delete(String key) {
        redisTemplate.delete(key);
    }

    public List<RedisKeyValueResponse> getAllKeyValues() {
        Set<String> keys = redisTemplate.keys("*");
        if (keys == null || keys.isEmpty()) {
            return List.of();
        }

        return keys.stream()
            .map(key -> new RedisKeyValueResponse(key, redisTemplate.opsForValue().get(key)))
            .collect(Collectors.toList());
    }

    public boolean exists(String key) {
        return redisTemplate.hasKey(key);
    }

    public void update(String key, String value) {
        if (exists(key)) {
            set(key, value);
        }
    }
}
