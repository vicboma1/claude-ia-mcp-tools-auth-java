package com.laberit.hospitalslanding.repository;

import com.laberit.hospitalslanding.model.SearchSnapshot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SearchSnapshotRepositoryTest {

    @Mock
    private SearchSnapshotRepository repository;

    private SearchSnapshot snapshot1;
    private SearchSnapshot snapshot2;
    private SearchSnapshot snapshot3;

    @BeforeEach
    void setUp() {
        // Crear snapshots de prueba
        snapshot1 = SearchSnapshot.builder()
                .id("id1")
                .tab("subscribers")
                .action("CREATE")
                .results(List.of(Map.of("id", 1, "email", "user1@example.com")))
                .resultCount(1)
                .timestamp(Instant.now().minusSeconds(3600))
                .performedBy("system")
                .details("Created user1")
                .build();

        snapshot2 = SearchSnapshot.builder()
                .id("id2")
                .tab("subscribers")
                .action("DELETE")
                .results(List.of())
                .resultCount(0)
                .timestamp(Instant.now().minusSeconds(1800))
                .performedBy("admin")
                .details("Deleted user2")
                .build();

        snapshot3 = SearchSnapshot.builder()
                .id("id3")
                .tab("subscribers")
                .action("LIST")
                .results(List.of(
                        Map.of("id", 1, "email", "user1@example.com"),
                        Map.of("id", 3, "email", "user3@example.com")
                ))
                .resultCount(2)
                .timestamp(Instant.now())
                .performedBy("system")
                .details("List all")
                .build();
    }

    @Test
    void testFindByTab() {
        // Arrange
        when(repository.findByTab("subscribers"))
                .thenReturn(List.of(snapshot1, snapshot2, snapshot3));

        // Act
        List<SearchSnapshot> results = repository.findByTab("subscribers");

        // Assert
        assertNotNull(results);
        assertEquals(3, results.size());
        assertTrue(results.stream().allMatch(s -> s.getTab().equals("subscribers")));
        verify(repository, times(1)).findByTab("subscribers");
    }

    @Test
    void testFindByAction() {
        // Arrange
        when(repository.findByAction("CREATE"))
                .thenReturn(List.of(snapshot1));

        // Act
        List<SearchSnapshot> results = repository.findByAction("CREATE");

        // Assert
        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("CREATE", results.get(0).getAction());
        verify(repository, times(1)).findByAction("CREATE");
    }

    @Test
    void testFindByTabAndAction() {
        // Arrange
        when(repository.findByTabAndAction("subscribers", "DELETE"))
                .thenReturn(List.of(snapshot2));

        // Act
        List<SearchSnapshot> results = repository.findByTabAndAction("subscribers", "DELETE");

        // Assert
        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("DELETE", results.get(0).getAction());
        assertEquals("subscribers", results.get(0).getTab());
        verify(repository, times(1)).findByTabAndAction("subscribers", "DELETE");
    }

    @Test
    void testFindByTimestampBetween() {
        // Arrange
        Instant start = Instant.now().minusSeconds(7200);
        Instant end = Instant.now();
        when(repository.findByTimestampBetween(start, end))
                .thenReturn(List.of(snapshot1, snapshot2, snapshot3));

        // Act
        List<SearchSnapshot> results = repository.findByTimestampBetween(start, end);

        // Assert
        assertNotNull(results);
        assertEquals(3, results.size());
        verify(repository, times(1)).findByTimestampBetween(start, end);
    }

    @Test
    void testFindByTabAndDateRange() {
        // Arrange
        Instant start = Instant.now().minusSeconds(7200);
        Instant end = Instant.now();
        when(repository.findByTabAndDateRange("subscribers", start, end))
                .thenReturn(List.of(snapshot1, snapshot2, snapshot3));

        // Act
        List<SearchSnapshot> results = repository.findByTabAndDateRange("subscribers", start, end);

        // Assert
        assertNotNull(results);
        assertEquals(3, results.size());
        verify(repository, times(1)).findByTabAndDateRange("subscribers", start, end);
    }

    @Test
    void testFindByPerformedBy() {
        // Arrange
        when(repository.findByPerformedBy("system"))
                .thenReturn(List.of(snapshot1, snapshot3));

        // Act
        List<SearchSnapshot> results = repository.findByPerformedBy("system");

        // Assert
        assertNotNull(results);
        assertEquals(2, results.size());
        assertTrue(results.stream().allMatch(s -> s.getPerformedBy().equals("system")));
        verify(repository, times(1)).findByPerformedBy("system");
    }

    @Test
    void testCountByTab() {
        // Arrange
        when(repository.countByTab("subscribers")).thenReturn(3L);

        // Act
        long count = repository.countByTab("subscribers");

        // Assert
        assertEquals(3L, count);
        verify(repository, times(1)).countByTab("subscribers");
    }

    @Test
    void testSaveAndFind() {
        // Arrange
        SearchSnapshot newSnapshot = SearchSnapshot.builder()
                .id("idNew")
                .tab("hospitals")
                .action("CREATE")
                .results(List.of(Map.of("id", 1, "name", "Hospital A")))
                .resultCount(1)
                .timestamp(Instant.now())
                .performedBy("doctor")
                .details("Created hospital")
                .build();

        when(repository.save(any(SearchSnapshot.class))).thenReturn(newSnapshot);
        when(repository.findById("idNew")).thenReturn(Optional.of(newSnapshot));

        // Act
        SearchSnapshot saved = repository.save(newSnapshot);

        // Assert
        assertNotNull(saved.getId());
        assertEquals("idNew", saved.getId());
        assertTrue(repository.findById(saved.getId()).isPresent());
        verify(repository, times(1)).save(any(SearchSnapshot.class));
    }

    @Test
    void testDeleteSnapshot() {
        // Arrange
        when(repository.countByTab("subscribers")).thenReturn(3L).thenReturn(2L);

        // Act
        long countBefore = repository.countByTab("subscribers");
        repository.delete(snapshot1);
        long countAfter = repository.countByTab("subscribers");

        // Assert
        assertEquals(3, countBefore);
        assertEquals(2, countAfter);
        verify(repository, times(1)).delete(snapshot1);
    }

    @Test
    void testFindByTabReturnsEmptyWhenNotFound() {
        // Arrange
        when(repository.findByTab("nonexistent")).thenReturn(List.of());

        // Act
        List<SearchSnapshot> results = repository.findByTab("nonexistent");

        // Assert
        assertNotNull(results);
        assertEquals(0, results.size());
        verify(repository, times(1)).findByTab("nonexistent");
    }

    @Test
    void testMultipleSnapshots() {
        // Arrange
        List<SearchSnapshot> snapshots = List.of(snapshot1, snapshot2, snapshot3);
        when(repository.findByTab("subscribers")).thenReturn(snapshots);

        // Act
        List<SearchSnapshot> results = repository.findByTab("subscribers");

        // Assert
        assertEquals(3, results.size());
        verify(repository, times(1)).findByTab("subscribers");
    }

    @Test
    void testResultCountIsPreserved() {
        // Arrange
        when(repository.findByTabAndAction("subscribers", "LIST"))
                .thenReturn(List.of(snapshot3));

        // Act
        SearchSnapshot found = repository.findByTabAndAction("subscribers", "LIST").get(0);

        // Assert
        assertEquals(2, found.getResultCount());
        verify(repository, times(1)).findByTabAndAction("subscribers", "LIST");
    }

    @Test
    void testDetailsFieldIsPreserved() {
        // Arrange
        when(repository.findByTabAndAction("subscribers", "CREATE"))
                .thenReturn(List.of(snapshot1));

        // Act
        SearchSnapshot found = repository.findByTabAndAction("subscribers", "CREATE").get(0);

        // Assert
        assertEquals("Created user1", found.getDetails());
        verify(repository, times(1)).findByTabAndAction("subscribers", "CREATE");
    }
}
