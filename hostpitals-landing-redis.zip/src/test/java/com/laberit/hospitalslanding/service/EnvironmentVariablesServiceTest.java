package com.laberit.hospitalslanding.service;

import com.laberit.hospitalslanding.dto.EnvironmentVariableResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("EnvironmentVariablesService Tests")
class EnvironmentVariablesServiceTest {

    private EnvironmentVariablesService service;

    @BeforeEach
    void setUp() {
        service = new EnvironmentVariablesService();
    }

    @Test
    @DisplayName("Should return all environment variables")
    void testGetAllEnvironmentVariables() {
        List<EnvironmentVariableResponse> variables = service.getAllEnvironmentVariables();
        assertNotNull(variables);
        assertFalse(variables.isEmpty());
        assertTrue(variables.size() > 0);
        assertTrue(variables.stream().allMatch(v -> v.getKey() != null && v.getValue() != null));
    }

    @Test
    @DisplayName("Should get existing environment variable")
    void testGetEnvironmentVariable_Exists() {
        String existingKey = "PATH";
        EnvironmentVariableResponse variable = service.getEnvironmentVariable(existingKey);
        assertNotNull(variable);
        assertEquals(existingKey, variable.getKey());
        assertNotNull(variable.getValue());
    }

    @Test
    @DisplayName("Should return null for non-existing environment variable")
    void testGetEnvironmentVariable_NotExists() {
        String nonExistingKey = "NON_EXISTING_ENV_VAR_12345_XYZ";
        EnvironmentVariableResponse variable = service.getEnvironmentVariable(nonExistingKey);
        assertNull(variable);
    }

    @Test
    @DisplayName("Should verify existence of environment variable")
    void testEnvironmentVariableExists_True() {
        String existingKey = "PATH";
        boolean exists = service.environmentVariableExists(existingKey);
        assertTrue(exists);
    }

    @Test
    @DisplayName("Should return false for non-existing environment variable")
    void testEnvironmentVariableExists_False() {
        String nonExistingKey = "NON_EXISTING_ENV_VAR_12345_XYZ";
        boolean exists = service.environmentVariableExists(nonExistingKey);
        assertFalse(exists);
    }

    @Test
    @DisplayName("Should count environment variables")
    void testCountEnvironmentVariables() {
        long count = service.countEnvironmentVariables();
        assertTrue(count > 0);
        assertEquals(System.getenv().size(), count);
    }

    @Test
    @DisplayName("Should return all variables when prefix is null")
    void testFilterEnvironmentVariables_NullPrefix() {
        List<EnvironmentVariableResponse> filtered = service.filterEnvironmentVariables(null);
        assertNotNull(filtered);
        assertEquals(service.getAllEnvironmentVariables().size(), filtered.size());
    }

    @Test
    @DisplayName("Should return all variables when prefix is empty")
    void testFilterEnvironmentVariables_EmptyPrefix() {
        List<EnvironmentVariableResponse> filtered = service.filterEnvironmentVariables("");
        assertNotNull(filtered);
        assertEquals(service.getAllEnvironmentVariables().size(), filtered.size());
    }

    @Test
    @DisplayName("Should filter environment variables case-insensitive")
    void testFilterEnvironmentVariables_CaseInsensitive() {
        List<EnvironmentVariableResponse> filtered = service.filterEnvironmentVariables("path");
        assertNotNull(filtered);
        assertTrue(filtered.size() > 0);
        assertTrue(filtered.stream().anyMatch(v -> v.getKey().equalsIgnoreCase("PATH")));
    }

    @Test
    @DisplayName("Should return empty list when no matches found")
    void testFilterEnvironmentVariables_NoMatches() {
        List<EnvironmentVariableResponse> filtered = service.filterEnvironmentVariables("NONEXISTENT_PREFIX_XYZ");
        assertNotNull(filtered);
        assertTrue(filtered.isEmpty());
    }

    @Test
    @DisplayName("Should return all variables when filtering with partial match")
    void testFilterEnvironmentVariables_PartialMatch() {
        List<EnvironmentVariableResponse> all = service.getAllEnvironmentVariables();
        if (all.size() > 0) {
            String firstKey = all.get(0).getKey();
            String partialKey = firstKey.substring(0, Math.min(3, firstKey.length()));
            List<EnvironmentVariableResponse> filtered = service.filterEnvironmentVariables(partialKey);
            assertNotNull(filtered);
            assertTrue(filtered.size() > 0);
        }
    }

    @Test
    @DisplayName("Should have consistent count with list size")
    void testCountConsistency() {
        long count = service.countEnvironmentVariables();
        List<EnvironmentVariableResponse> all = service.getAllEnvironmentVariables();
        assertEquals(count, all.size());
    }

    @Test
    @DisplayName("Should handle special characters in search")
    void testFilterEnvironmentVariables_SpecialCharacters() {
        List<EnvironmentVariableResponse> filtered = service.filterEnvironmentVariables("_");
        assertNotNull(filtered);
    }
}
