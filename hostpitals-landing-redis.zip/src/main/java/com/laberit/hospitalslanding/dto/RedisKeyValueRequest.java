package com.laberit.hospitalslanding.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RedisKeyValueRequest {
    @NotBlank(message = "La clave no puede estar vacía")
    private String key;

    @NotBlank(message = "El valor no puede estar vacío")
    private String value;
}
