#!/bin/bash

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${BLUE}  🐳 Docker Build & Test               ${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}\n"

# Verificar que Docker está instalado
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker no está instalado${NC}"
    exit 1
fi

echo -e "${YELLOW}📋 Información de Docker:${NC}"
docker --version
docker-compose --version 2>/dev/null || echo "Docker Compose no instalado"
echo ""

# Verificar que existe el Dockerfile
if [ ! -f "Dockerfile" ]; then
    echo -e "${RED}❌ Dockerfile no encontrado${NC}"
    exit 1
fi

echo -e "${YELLOW}🔨 Compilando imagen Docker...${NC}"
echo "Esto puede tardar varios minutos (descargando dependencias, compilando, tests...)"
echo ""

docker build \
    --progress=plain \
    -t hospitals-landing:latest \
    -t hospitals-landing:$(date +%Y%m%d-%H%M%S) \
    .

BUILD_RESULT=$?

if [ $BUILD_RESULT -eq 0 ]; then
    echo -e "\n${GREEN}✅ Imagen compilada exitosamente${NC}\n"
else
    echo -e "\n${RED}❌ Error al compilar imagen${NC}\n"
    exit 1
fi

# Mostrar resumen
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ DOCKER BUILD COMPLETADO${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}\n"

echo -e "${YELLOW}📊 Imágenes creadas:${NC}"
docker images | grep hospitals-landing
echo ""

echo -e "${YELLOW}🚀 Próximos pasos:${NC}"
echo ""
echo "Para ejecutar todo el stack:"
echo "  docker-compose -f docker-compose.full.yml up -d"
echo ""
echo "Para ejecutar solo la aplicación:"
echo "  docker run -it --rm -p 8080:8080 hospitals-landing:latest"
echo ""
echo "Para ver logs:"
echo "  docker logs -f hospitals-landing"
echo ""
echo -e "${BLUE}════════════════════════════════════════${NC}\n"
