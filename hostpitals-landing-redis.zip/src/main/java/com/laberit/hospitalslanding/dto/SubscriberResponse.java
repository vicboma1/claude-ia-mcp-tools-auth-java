package com.laberit.hospitalslanding.dto;

import com.laberit.hospitalslanding.model.Subscriber;

import java.time.Instant;

public class SubscriberResponse {

    private Long id;
    private String email;
    private Instant createdAt;

    public SubscriberResponse() {
    }

    public SubscriberResponse(Long id, String email, Instant createdAt) {
        this.id = id;
        this.email = email;
        this.createdAt = createdAt;
    }

    public static SubscriberResponse from(Subscriber subscriber) {
        return new SubscriberResponse(subscriber.getId(), subscriber.getEmail(), subscriber.getCreatedAt());
    }

    public Long getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
