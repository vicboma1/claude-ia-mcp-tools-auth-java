# HospitalConnect · Landing + CRUD de suscriptores

Landing page *one-page* de un proyecto de hospitales (Java 17 + Spring Boot),
con un formulario de correo al final de la página. Los correos se guardan en
PostgreSQL con un CRUD completo (crear desde la landing, listar y eliminar
desde un panel de administración). Las properties de configuración están
externalizadas para poder leerse desde variables de entorno en local/Docker,
o desde **AWS Secrets Manager** en un entorno AWS.

## Estructura del proyecto

```
hospitals-landing/
├── Dockerfile                  # build multi-stage de la app Spring Boot
├── docker-compose.yml          # app + PostgreSQL
├── .env.example                # variables de entorno de ejemplo
├── pom.xml
├── src/main/java/com/laberit/hospitalslanding/
│   ├── HospitalsLandingApplication.java
│   ├── model/Subscriber.java
│   ├── repository/SubscriberRepository.java
│   ├── dto/                    # SubscriberRequest / SubscriberResponse
│   ├── service/SubscriberService.java
│   ├── controller/SubscriberController.java   # CRUD REST
│   ├── exception/               # manejo de errores (duplicados, 404, validación)
│   └── config/SecurityConfig.java             # HTTP Basic para el panel admin
├── src/main/resources/
│   ├── application.yml         # properties externalizadas (perfil "default")
│   ├── application-aws.yml     # properties vía AWS Secrets Manager (perfil "aws")
│   └── static/
│       ├── index.html          # landing one-page (con el formulario de correo)
│       ├── admin.html          # panel para listar / eliminar suscriptores
│       ├── css/styles.css
│       └── js/{main.js, admin.js}
└── src/test/java/...
```

## Endpoints

| Método | Ruta                     | Acceso        | Descripción                          |
|--------|--------------------------|---------------|---------------------------------------|
| GET    | `/`                      | público       | Landing page                          |
| POST   | `/api/subscribers`       | público       | Alta de un correo `{ "email": "..." }`|
| GET    | `/admin.html`            | admin (Basic) | Panel de administración               |
| GET    | `/api/subscribers`       | admin (Basic) | Listar suscriptores                   |
| DELETE | `/api/subscribers/{id}`  | admin (Basic) | Eliminar un suscriptor                |
| GET    | `/actuator/health`       | público       | Health check (usado por Docker)       |

Las credenciales de administrador (`ADMIN_USER` / `ADMIN_PASSWORD`) también
son properties externalizadas — no están hardcodeadas.

## Ejecutar en local con Docker

Requisitos: Docker y Docker Compose.

```bash
cp .env.example .env
# (opcional) edita .env con tus propios valores

docker compose up --build
```

- Landing: http://localhost:8080
- Panel admin: http://localhost:8080/admin.html (usuario/clave de `.env`,
  por defecto `admin` / `changeme` — cámbialo)
- PostgreSQL queda expuesto en `localhost:5432` con los datos de `.env`

Para parar y borrar los datos de la base de datos:

```bash
docker compose down -v
```

## Probar el CRUD por API

```bash
# Crear (público)
curl -X POST http://localhost:8080/api/subscribers \
  -H "Content-Type: application/json" \
  -d '{"email":"alguien@ejemplo.com"}'

# Listar (requiere admin)
curl -u admin:changeme http://localhost:8080/api/subscribers

# Eliminar (requiere admin)
curl -u admin:changeme -X DELETE http://localhost:8080/api/subscribers/1
```

## Properties externalizadas y AWS Secrets Manager

Todas las properties sensibles/variables (`DB_HOST`, `DB_PORT`, `DB_NAME`,
`DB_USER`, `DB_PASSWORD`, `ADMIN_USER`, `ADMIN_PASSWORD`) se leen de
variables de entorno en `application.yml` — nunca están escritas en el
código ni en el `.jar`.

Para producción en AWS, se usa el perfil `aws` (`spring-cloud-aws-starter-secrets-manager`),
que carga esas mismas properties directamente desde un secreto de
**AWS Secrets Manager**, sin cambiar una línea de código:

1. Crea un secreto en Secrets Manager (nombre por defecto `hospitals-landing/db`,
   configurable con `AWS_SECRET_NAME`) con un JSON plano:

   ```json
   {
     "DB_HOST": "mi-rds.xxxxxxxx.eu-west-1.rds.amazonaws.com",
     "DB_PORT": "5432",
     "DB_NAME": "hospitals",
     "DB_USER": "hospitals",
     "DB_PASSWORD": "un-password-fuerte",
     "ADMIN_USER": "admin",
     "ADMIN_PASSWORD": "otro-password-fuerte"
   }
   ```

2. Da permiso `secretsmanager:GetSecretValue` sobre ese secreto al rol de
   IAM que use la tarea/instancia donde corra la app (rol de tarea ECS,
   perfil de instancia EC2, IRSA en EKS, etc.). No hace falta poner claves
   de acceso en ningún fichero: se usa la cadena de credenciales por
   defecto del SDK de AWS.

3. Arranca la app con:

   ```bash
   SPRING_PROFILES_ACTIVE=aws
   AWS_REGION=eu-west-1
   AWS_SECRET_NAME=hospitals-landing/db
   ```

   (en `docker-compose.yml` basta con poner esas variables en `.env`).

Con el perfil `default` (el que usa `docker-compose.yml` tal cual), las
mismas properties se resuelven desde variables de entorno normales — útil
para desarrollo local sin depender de AWS.

## Notas de seguridad

- El formulario público solo puede **crear** correos (`POST`); listar y
  eliminar requieren autenticación de administrador (HTTP Basic).
- Los correos se normalizan (trim + minúsculas) y son únicos en base de
  datos; un alta duplicada devuelve `409 Conflict`.
- Este proyecto usa HTTP Basic por simplicidad; para un entorno productivo
  con más de un administrador se recomendaría evolucionar a un login con
  JWT/OAuth2 y roles gestionados aparte.
