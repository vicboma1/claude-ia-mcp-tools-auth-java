// API de Variables de Entorno
const envApi = {
  baseUrl: '/api/admin/environment',

  async getAll() {
    return this.request('GET', '/all');
  },

  async get(key) {
    return this.request('GET', `/${encodeURIComponent(key)}`);
  },

  async search(query) {
    return this.request('GET', '/search?query=' + encodeURIComponent(query));
  },

  async getCount() {
    return this.request('GET', '/count');
  },

  async request(method, endpoint) {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Basic ' + btoa('admin:changeme')
      }
    };

    const response = await fetch(this.baseUrl + endpoint, options);

    if (!response.ok) {
      throw new Error(`Error: ${response.status} ${response.statusText}`);
    }

    if (response.status === 204) return null;
    return response.json();
  }
};

// Cargar lista de variables de entorno
async function loadEnvironmentVariables() {
  const listEl = document.getElementById('env-list');
  const countEl = document.getElementById('env-count-label');
  const msgEl = document.getElementById('env-message');

  msgEl.textContent = '';
  listEl.innerHTML = '<div class="redis-empty">Cargando…</div>';

  try {
    const data = await envApi.getAll();

    if (!data || data.length === 0) {
      listEl.innerHTML = '<div class="redis-empty">No hay variables de entorno</div>';
      countEl.textContent = '0 variables';
      return;
    }

    countEl.textContent = `${data.length} variable${data.length !== 1 ? 's' : ''}`;

    listEl.innerHTML = data.map(item => `
      <div class="redis-item">
        <div class="redis-item-key" title="${item.key}">${escapeHtml(item.key)}</div>
        <div class="redis-item-value" title="${item.value}">${escapeHtml(item.value)}</div>
        <div class="redis-actions">
          <button class="btn btn-small btn-secondary" onclick="copyToClipboard('${escapeAttr(item.value)}')">Copiar</button>
        </div>
      </div>
    `).join('');
  } catch (error) {
    msgEl.textContent = `Error: ${error.message}`;
    listEl.innerHTML = '<div class="redis-empty">Error al cargar las variables</div>';
  }
}

// Buscar variables de entorno
async function searchEnvironmentVariables(query) {
  const listEl = document.getElementById('env-list');
  const countEl = document.getElementById('env-count-label');
  const msgEl = document.getElementById('env-message');

  if (!query || query.trim() === '') {
    loadEnvironmentVariables();
    return;
  }

  msgEl.textContent = '';
  listEl.innerHTML = '<div class="redis-empty">Buscando…</div>';

  try {
    const data = await envApi.search(query.trim());

    if (!data || data.length === 0) {
      listEl.innerHTML = `<div class="redis-empty">No hay coincidencias para "${escapeHtml(query)}"</div>`;
      countEl.textContent = '0 variables';
      return;
    }

    countEl.textContent = `${data.length} coincidencia${data.length !== 1 ? 's' : ''}`;

    listEl.innerHTML = data.map(item => `
      <div class="redis-item">
        <div class="redis-item-key" title="${item.key}">${escapeHtml(item.key)}</div>
        <div class="redis-item-value" title="${item.value}">${escapeHtml(item.value)}</div>
        <div class="redis-actions">
          <button class="btn btn-small btn-secondary" onclick="copyToClipboard('${escapeAttr(item.value)}')">Copiar</button>
        </div>
      </div>
    `).join('');
  } catch (error) {
    msgEl.textContent = `Error: ${error.message}`;
    listEl.innerHTML = '<div class="redis-empty">Error al buscar variables</div>';
  }
}

// Copiar al portapapeles
window.copyToClipboard = (text) => {
  navigator.clipboard.writeText(text).then(() => {
    const msgEl = document.getElementById('env-message');
    msgEl.textContent = '✓ Copiado al portapapeles';
    msgEl.style.color = '#27ae60';
    setTimeout(() => msgEl.textContent = '', 2000);
  }).catch(err => {
    const msgEl = document.getElementById('env-message');
    msgEl.textContent = '✗ Error al copiar';
    msgEl.style.color = '#d84d42';
  });
};

// Botón de actualizar
document.getElementById('env-refresh-btn').addEventListener('click', loadEnvironmentVariables);

// Búsqueda en tiempo real
const searchInput = document.getElementById('env-search-input');
let searchTimeout;
searchInput.addEventListener('input', (e) => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    searchEnvironmentVariables(e.target.value);
  }, 300);
});

// Cargar datos cuando se activa la pestaña
document.addEventListener('DOMContentLoaded', () => {
  const envTab = document.querySelector('[data-tab="environment"]');
  if (envTab) {
    envTab.addEventListener('click', () => {
      setTimeout(loadEnvironmentVariables, 50);
    });
  }
});

// Utilidades
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

function escapeAttr(text) {
  return text.replace(/'/g, "\\'");
}
