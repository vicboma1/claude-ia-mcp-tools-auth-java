package com.laberit.hospitalslanding.service;

import com.laberit.hospitalslanding.dto.SubscriberResponse;
import com.laberit.hospitalslanding.exception.DuplicateEmailException;
import com.laberit.hospitalslanding.exception.SubscriberNotFoundException;
import com.laberit.hospitalslanding.model.Subscriber;
import com.laberit.hospitalslanding.repository.SubscriberRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SubscriberService {

    private final SubscriberRepository repository;

    public SubscriberService(SubscriberRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public SubscriberResponse create(String email) {
        String normalized = email.trim().toLowerCase();
        if (repository.existsByEmailIgnoreCase(normalized)) {
            throw new DuplicateEmailException(normalized);
        }
        Subscriber saved = repository.save(new Subscriber(normalized));
        return SubscriberResponse.from(saved);
    }

    @Transactional(readOnly = true)
    public List<SubscriberResponse> findAll() {
        return repository.findAll().stream()
                .sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()))
                .map(SubscriberResponse::from)
                .toList();
    }

    @Transactional
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new SubscriberNotFoundException(id);
        }
        repository.deleteById(id);
    }
}
