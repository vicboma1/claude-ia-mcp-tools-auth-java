package com.laberit.hospitalslanding;

import org.junit.jupiter.api.Test;

class HospitalsLandingApplicationTests {

    @Test
    void contextLoadsPlaceholder() {
        // Prueba de humo mínima. La carga completa del contexto Spring requiere
        // una base de datos PostgreSQL disponible (ver docker-compose.yml);
        // en CI/local sin BD, ejecutar `docker compose up db` antes de `mvn test`
        // si se añaden tests de integración con @SpringBootTest.
    }
}
