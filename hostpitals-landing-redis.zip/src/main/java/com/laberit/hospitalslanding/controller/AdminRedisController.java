package com.laberit.hospitalslanding.controller;

import com.laberit.hospitalslanding.dto.RedisKeyValueRequest;
import com.laberit.hospitalslanding.dto.RedisKeyValueResponse;
import com.laberit.hospitalslanding.service.RedisService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/redis")
public class AdminRedisController {

    private final RedisService redisService;

    public AdminRedisController(RedisService redisService) {
        this.redisService = redisService;
    }

    @GetMapping("/ping")
    public ResponseEntity<String> ping() {
        return ResponseEntity.ok("Redis Admin API - PONG");
    }

    @GetMapping("/all")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<RedisKeyValueResponse>> getAllKeyValues() {
        return ResponseEntity.ok(redisService.getAllKeyValues());
    }

    @GetMapping("/{key}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RedisKeyValueResponse> getKeyValue(@PathVariable String key) {
        String value = redisService.get(key);
        if (value == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(new RedisKeyValueResponse(key, value));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RedisKeyValueResponse> addKeyValue(@Valid @RequestBody RedisKeyValueRequest request) {
        redisService.set(request.getKey(), request.getValue());
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(new RedisKeyValueResponse(request.getKey(), request.getValue()));
    }

    @PutMapping("/{key}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<RedisKeyValueResponse> updateKeyValue(
        @PathVariable String key,
        @Valid @RequestBody RedisKeyValueRequest request) {
        if (!redisService.exists(key)) {
            return ResponseEntity.notFound().build();
        }
        redisService.set(key, request.getValue());
        return ResponseEntity.ok(new RedisKeyValueResponse(key, request.getValue()));
    }

    @DeleteMapping("/{key}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteKeyValue(@PathVariable String key) {
        if (!redisService.exists(key)) {
            return ResponseEntity.notFound().build();
        }
        redisService.delete(key);
        return ResponseEntity.noContent().build();
    }
}
