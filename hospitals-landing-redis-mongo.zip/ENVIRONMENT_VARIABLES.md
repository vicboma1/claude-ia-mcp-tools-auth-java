# 🔧 Variables de Entorno - Hospitals Landing

## 📋 Tabla Completa de Variables Globales

Todas las variables que necesitas en AWS (o Docker) para que la app y sus dependencias funcionen.

---

## 🎯 PERFIL Y AWS

| Variable | Descripción | Defecto | Ej. AWS | Obligatoria |
|---|---|---|---|---|
| `SPRING_PROFILES_ACTIVE` | Perfil de Spring (default o aws) | `default` | `aws` | ⚠️ Recomendado |
| `AWS_REGION` | Región de AWS | `eu-west-1` | `eu-west-1` | ❌ (si usas aws) |
| `AWS_SECRET_NAME` | Nombre del secreto en AWS Secrets Manager | `hospitals-landing/db` | `hospitals-landing/db` | ❌ (si usas aws) |
| `AWS_ACCESS_KEY_ID` | Access key de AWS | — | — | ❌ (usa IAM role) |
| `AWS_SECRET_ACCESS_KEY` | Secret key de AWS | — | — | ❌ (usa IAM role) |
| `AWS_SESSION_TOKEN` | Token de sesión STS | — | — | ❌ (usa IAM role) |

---

## 🗄️ PostgreSQL

| Variable | Descripción | Defecto | Ej. AWS | Obligatoria |
|---|---|---|---|---|
| `DB_HOST` | Host de PostgreSQL | `localhost` | `hospitals-prod-db.xxxxx.eu-west-1.rds.amazonaws.com` | ✅ Sí |
| `DB_PORT` | Puerto PostgreSQL | `5432` | `5432` | ✅ Sí |
| `DB_NAME` | Nombre de BD | `hospitals` | `hospitals_prod` | ✅ Sí |
| `DB_USER` | Usuario PostgreSQL | `hospitals` | `hospitals_user` | ✅ Sí |
| `DB_PASSWORD` | Contraseña PostgreSQL | `hospitals` | `super-secreto-xxx` | ✅ Sí |
| `JPA_DDL_AUTO` | Estrategia DDL (create/update/validate) | `update` | `validate` | ❌ |
| `JPA_SHOW_SQL` | Mostrar SQL en logs | `false` | `false` | ❌ |

---

## 📊 MongoDB

| Variable | Descripción | Defecto | Ej. AWS | Obligatoria |
|---|---|---|---|---|
| `MONGO_HOST` | Host de MongoDB | `localhost` | `hospitals-docdb.xxxxx.eu-west-1.docdb.amazonaws.com` | ✅ Sí |
| `MONGO_PORT` | Puerto MongoDB | `27017` | `27017` | ✅ Sí |
| `MONGO_DB` | Nombre de BD MongoDB | `hospitals-snapshots` | `hospitals_snapshots_prod` | ✅ Sí |
| `MONGO_ADMIN_USER` | Usuario admin MongoDB | `admin` | `admin_user` | ✅ Sí |
| `MONGO_ADMIN_PASSWORD` | Contraseña admin MongoDB | `password` | `mongo-secret-xxx` | ✅ Sí |
| `MONGODB_URI` | URI completa de MongoDB (opcional) | — | `mongodb://user:pass@host:27017/db` | ❌ (alternativa) |

---

## 🔴 Redis

| Variable | Descripción | Defecto | Ej. AWS | Obligatoria |
|---|---|---|---|---|
| `REDIS_HOST` | Host de Redis | `localhost` | `hospitals-redis.xxxxx.eu-west-1.elasticache.amazonaws.com` | ✅ Sí |
| `REDIS_PORT` | Puerto Redis | `6379` | `6379` | ✅ Sí |
| `REDIS_PASSWORD` | Contraseña Redis | `redis123` | `redis-secret-xxx` | ✅ Sí |
| `REDIS_ENABLED` | Activar Redis | `true` | `true` | ❌ |
| `REDIS_TTL` | TTL por defecto (ms) | `0` | `3600000` | ❌ |
| `REDIS_MAX_CONNECTIONS` | Conexiones máximas | `8` | `20` | ❌ |
| `REDIS_MIN_IDLE_CONNECTIONS` | Conexiones mínimas | `0` | `2` | ❌ |

---

## 🖥️ Servidor

| Variable | Descripción | Defecto | Ej. AWS | Obligatoria |
|---|---|---|---|---|
| `SERVER_PORT` | Puerto del servidor | `8080` | `8080` | ❌ |

---

## 🔐 Admin / Seguridad

| Variable | Descripción | Defecto | Ej. AWS | Obligatoria |
|---|---|---|---|---|
| `ADMIN_USER` | Usuario admin | `admin` | `admin_hospitals` | ✅ Sí |
| `ADMIN_PASSWORD` | Contraseña admin | `changeme` | `admin-secure-xxx` | ✅ Sí |

---

## 📋 UI Admin (Opcionales)

| Variable | Descripción | Defecto | Ej. AWS | Obligatoria |
|---|---|---|---|---|
| `ME_ADMIN_USER` | Usuario Mongo Express | `admin` | `admin` | ❌ |
| `ME_ADMIN_PASSWORD` | Contraseña Mongo Express | `password` | `mongo-express-xxx` | ❌ |

---

## 📊 Secreto JSON en AWS Secrets Manager

Cuando usas `SPRING_PROFILES_ACTIVE=aws`, la app lee este JSON del secreto:

```json
{
  "DB_HOST": "hospitals-prod-db.xxxxx.eu-west-1.rds.amazonaws.com",
  "DB_PORT": "5432",
  "DB_NAME": "hospitals_prod",
  "DB_USER": "hospitals_user",
  "DB_PASSWORD": "super-secret-password-xxx",
  
  "MONGO_HOST": "hospitals-docdb.xxxxx.eu-west-1.docdb.amazonaws.com",
  "MONGO_PORT": "27017",
  "MONGO_DB": "hospitals_snapshots_prod",
  "MONGO_ADMIN_USER": "admin_user",
  "MONGO_ADMIN_PASSWORD": "mongo-secret-xxx",
  "MONGODB_URI": "mongodb://admin_user:mongo-secret-xxx@hospitals-docdb.xxxxx.eu-west-1.docdb.amazonaws.com:27017/hospitals_snapshots_prod",
  
  "REDIS_HOST": "hospitals-redis.xxxxx.eu-west-1.elasticache.amazonaws.com",
  "REDIS_PORT": "6379",
  "REDIS_PASSWORD": "redis-secret-xxx",
  
  "ADMIN_USER": "admin_hospitals",
  "ADMIN_PASSWORD": "admin-secure-xxx"
}
```

---

## 🐳 Docker Compose - Ejemplo Completo

```bash
# En .env (mismo directorio que docker-compose)
DB_NAME=hospitals
DB_USER=hospitals
DB_PASSWORD=super-secret
MONGO_ADMIN_USER=admin
MONGO_ADMIN_PASSWORD=mongo-secret
REDIS_PASSWORD=redis-secret
ADMIN_USER=admin
ADMIN_PASSWORD=admin-secure

# Luego:
docker-compose -f docker-compose.full.yml up -d
```

---

## ✅ Checklist para AWS

### 1️⃣ Configurar AWS Secrets Manager

```bash
aws secretsmanager create-secret \
  --name hospitals-landing/db \
  --secret-string '{
    "DB_HOST": "tu-rds.xxxxx.eu-west-1.rds.amazonaws.com",
    "DB_PORT": "5432",
    "DB_NAME": "hospitals_prod",
    "DB_USER": "hospitals_user",
    "DB_PASSWORD": "xxx",
    "MONGO_HOST": "tu-docdb.xxxxx.eu-west-1.docdb.amazonaws.com",
    "MONGO_PORT": "27017",
    "MONGO_DB": "hospitals_snapshots_prod",
    "MONGO_ADMIN_USER": "admin",
    "MONGO_ADMIN_PASSWORD": "xxx",
    "MONGODB_URI": "mongodb://admin:xxx@tu-docdb:27017/hospitals_snapshots_prod",
    "REDIS_HOST": "tu-redis.xxxxx.eu-west-1.elasticache.amazonaws.com",
    "REDIS_PORT": "6379",
    "REDIS_PASSWORD": "xxx",
    "ADMIN_USER": "admin_hospitals",
    "ADMIN_PASSWORD": "xxx"
  }' \
  --region eu-west-1
```

### 2️⃣ ECS Task Definition

```json
{
  "containerDefinitions": [
    {
      "name": "hospitals-landing",
      "image": "tu-registry/hospitals-landing:latest",
      "portMappings": [
        {
          "containerPort": 8080,
          "hostPort": 8080,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "SPRING_PROFILES_ACTIVE",
          "value": "aws"
        },
        {
          "name": "AWS_SECRET_NAME",
          "value": "hospitals-landing/db"
        },
        {
          "name": "AWS_REGION",
          "value": "eu-west-1"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/hospitals-landing",
          "awslogs-region": "eu-west-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ],
  "taskRoleArn": "arn:aws:iam::ACCOUNT:role/ecsTaskRole",
  "executionRoleArn": "arn:aws:iam::ACCOUNT:role/ecsTaskExecutionRole"
}
```

### 3️⃣ IAM Policy (para que ECS pueda leer el secreto)

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "secretsmanager:GetSecretValue"
      ],
      "Resource": "arn:aws:secretsmanager:eu-west-1:ACCOUNT:secret:hospitals-landing/db-*"
    }
  ]
}
```

---

## 📝 Notas Importantes

### Local (Docker Compose)
- Usa el perfil **`default`** (SPRING_PROFILES_ACTIVE=default)
- Las variables se pasan en `.env` o en el archivo `docker-compose.yml`
- Las contraseñas pueden ser simples (es local)

### AWS (ECS/RDS/DocumentDB/ElastiCache)
- Usa el perfil **`aws`** (SPRING_PROFILES_ACTIVE=aws)
- Las variables se leen desde **AWS Secrets Manager**
- Solo necesitas 3 variables en ECS:
  - `SPRING_PROFILES_ACTIVE=aws`
  - `AWS_SECRET_NAME=hospitals-landing/db`
  - `AWS_REGION=eu-west-1`
- Las credenciales de AWS se resuelven automáticamente (no declarar AWS_ACCESS_KEY_ID, etc.)

---

## 🔗 Orden de Prioridad (Donde se lee cada variable)

1. **AWS Secrets Manager** (si SPRING_PROFILES_ACTIVE=aws)
2. **Variables de entorno locales** (si SPRING_PROFILES_ACTIVE=default)
3. **Valores por defecto** (en application.yml)

---

## 📌 Resumen: Variables Obligatorias MÍNIMAS

Para que la app funcione en **cualquier entorno**:

```
✅ Obligatorias:
  - DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD
  - MONGO_HOST, MONGO_PORT, MONGO_DB, MONGO_ADMIN_USER, MONGO_ADMIN_PASSWORD
  - REDIS_HOST, REDIS_PORT, REDIS_PASSWORD
  - ADMIN_USER, ADMIN_PASSWORD

⚠️ Muy recomendadas (para AWS):
  - SPRING_PROFILES_ACTIVE=aws
  - AWS_SECRET_NAME
  - AWS_REGION
```

¡Todo listo para AWS! 🚀
