// Manejo de pestañas
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const tabName = btn.dataset.tab;

    // Desactivar todos los tabs
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

    // Activar el seleccionado
    btn.classList.add('active');
    document.getElementById(tabName).classList.add('active');

    // Cargar datos si es Redis
    if (tabName === 'redis') {
      loadRedisKeys();
    }
  });
});

// API de Redis
const redisApi = {
  baseUrl: '/api/admin/redis',

  async getAll() {
    return this.request('GET', '/all');
  },

  async get(key) {
    return this.request('GET', `/${encodeURIComponent(key)}`);
  },

  async add(key, value) {
    return this.request('POST', '', { key, value });
  },

  async update(key, value) {
    return this.request('PUT', `/${encodeURIComponent(key)}`, { value });
  },

  async delete(key) {
    return this.request('DELETE', `/${encodeURIComponent(key)}`);
  },

  async request(method, endpoint, body = null) {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Basic ' + btoa('admin:changeme')
      }
    };

    if (body) options.body = JSON.stringify(body);

    const response = await fetch(this.baseUrl + endpoint, options);

    if (!response.ok) {
      throw new Error(`Error: ${response.status} ${response.statusText}`);
    }

    if (response.status === 204) return null;
    return response.json();
  }
};

// Cargar lista de claves
async function loadRedisKeys() {
  const listEl = document.getElementById('redis-list');
  const countEl = document.getElementById('redis-count-label');
  const msgEl = document.getElementById('redis-message');

  msgEl.textContent = '';
  listEl.innerHTML = '<div class="redis-empty">Cargando…</div>';

  try {
    const data = await redisApi.getAll();

    if (!data || data.length === 0) {
      listEl.innerHTML = '<div class="redis-empty">No hay claves almacenadas</div>';
      countEl.textContent = '0 claves';
      return;
    }

    countEl.textContent = `${data.length} clave${data.length !== 1 ? 's' : ''}`;

    listEl.innerHTML = data.map(item => `
      <div class="redis-item">
        <div class="redis-item-key" title="${item.key}">${escapeHtml(item.key)}</div>
        <div class="redis-item-value" title="${item.value}">${escapeHtml(item.value)}</div>
        <div class="redis-actions">
          <button class="btn btn-small btn-secondary" onclick="editRedisKey('${escapeAttr(item.key)}', '${escapeAttr(item.value)}')">Editar</button>
          <button class="btn btn-small btn-danger" onclick="deleteRedisKey('${escapeAttr(item.key)}')">Eliminar</button>
        </div>
      </div>
    `).join('');
  } catch (error) {
    msgEl.textContent = `Error: ${error.message}`;
    listEl.innerHTML = '<div class="redis-empty">Error al cargar las claves</div>';
  }
}

// Agregar clave
document.getElementById('redis-add-btn').addEventListener('click', async () => {
  const keyInput = document.getElementById('redis-key-input');
  const valueInput = document.getElementById('redis-value-input');
  const msgEl = document.getElementById('redis-message');

  const key = keyInput.value.trim();
  const value = valueInput.value.trim();

  if (!key || !value) {
    msgEl.textContent = '⚠️ La clave y el valor no pueden estar vacíos';
    msgEl.style.color = '#d84d42';
    return;
  }

  try {
    await redisApi.add(key, value);
    msgEl.textContent = '✓ Clave agregada correctamente';
    msgEl.style.color = '#27ae60';
    keyInput.value = '';
    valueInput.value = '';
    setTimeout(() => msgEl.textContent = '', 3000);
    loadRedisKeys();
  } catch (error) {
    msgEl.textContent = `✗ Error: ${error.message}`;
    msgEl.style.color = '#d84d42';
  }
});

// Actualizar clave
window.editRedisKey = async (key, currentValue) => {
  const newValue = prompt('Nuevo valor:', currentValue);
  if (newValue === null) return;

  if (!newValue.trim()) {
    alert('El valor no puede estar vacío');
    return;
  }

  const msgEl = document.getElementById('redis-message');
  try {
    await redisApi.update(key, newValue);
    msgEl.textContent = '✓ Clave actualizada correctamente';
    msgEl.style.color = '#27ae60';
    setTimeout(() => msgEl.textContent = '', 3000);
    loadRedisKeys();
  } catch (error) {
    msgEl.textContent = `✗ Error: ${error.message}`;
    msgEl.style.color = '#d84d42';
  }
};

// Eliminar clave
window.deleteRedisKey = async (key) => {
  if (!confirm(`¿Eliminar la clave "${key}"?`)) return;

  const msgEl = document.getElementById('redis-message');
  try {
    await redisApi.delete(key);
    msgEl.textContent = '✓ Clave eliminada correctamente';
    msgEl.style.color = '#27ae60';
    setTimeout(() => msgEl.textContent = '', 3000);
    loadRedisKeys();
  } catch (error) {
    msgEl.textContent = `✗ Error: ${error.message}`;
    msgEl.style.color = '#d84d42';
  }
};

// Botón de actualizar
document.getElementById('redis-refresh-btn').addEventListener('click', loadRedisKeys);

// Enter en inputs
document.getElementById('redis-key-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') document.getElementById('redis-value-input').focus();
});

document.getElementById('redis-value-input').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') document.getElementById('redis-add-btn').click();
});

// Utilidades
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

function escapeAttr(text) {
  return text.replace(/'/g, "\\'");
}
