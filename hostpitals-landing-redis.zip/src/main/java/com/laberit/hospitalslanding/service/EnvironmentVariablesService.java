package com.laberit.hospitalslanding.service;

import com.laberit.hospitalslanding.dto.EnvironmentVariableResponse;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class EnvironmentVariablesService {

    public List<EnvironmentVariableResponse> getAllEnvironmentVariables() {
        return System.getenv().entrySet().stream()
            .map(entry -> new EnvironmentVariableResponse(entry.getKey(), entry.getValue()))
            .collect(Collectors.toList());
    }

    public EnvironmentVariableResponse getEnvironmentVariable(String key) {
        String value = System.getenv(key);
        if (value == null) {
            return null;
        }
        return new EnvironmentVariableResponse(key, value);
    }

    public boolean environmentVariableExists(String key) {
        return System.getenv(key) != null;
    }

    public long countEnvironmentVariables() {
        return System.getenv().size();
    }

    public List<EnvironmentVariableResponse> filterEnvironmentVariables(String prefix) {
        if (prefix == null || prefix.isEmpty()) {
            return getAllEnvironmentVariables();
        }

        String lowerPrefix = prefix.toLowerCase();
        return System.getenv().entrySet().stream()
            .filter(entry -> entry.getKey().toLowerCase().contains(lowerPrefix))
            .map(entry -> new EnvironmentVariableResponse(entry.getKey(), entry.getValue()))
            .collect(Collectors.toList());
    }
}
