package com.laberit.hospitalslanding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalsLandingApplication {

    public static void main(String[] args) {
        SpringApplication.run(HospitalsLandingApplication.class, args);
    }
}
