const tbody = document.getElementById("subscribers-body");
const countLabel = document.getElementById("count-label");
const messageEl = document.getElementById("admin-message");
const refreshBtn = document.getElementById("refresh-btn");

function setMessage(text, type) {
  messageEl.textContent = text || "";
  messageEl.classList.remove("success", "error");
  if (type) {
    messageEl.classList.add(type);
  }
}

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleString();
  } catch (e) {
    return iso;
  }
}

async function loadSubscribers() {
  tbody.innerHTML = "<tr><td colspan=\"4\">Cargando…</td></tr>";
  setMessage("", null);

  try {
    const response = await fetch("/api/subscribers", { credentials: "same-origin" });

    if (response.status === 401) {
      setMessage("No autorizado. Recarga la página e introduce las credenciales de administrador.", "error");
      tbody.innerHTML = "";
      return;
    }

    const data = await response.json();
    countLabel.textContent = `${data.length} suscriptor(es)`;

    if (data.length === 0) {
      tbody.innerHTML = "<tr><td colspan=\"4\">Todavía no hay suscriptores.</td></tr>";
      return;
    }

    tbody.innerHTML = "";
    for (const sub of data) {
      const tr = document.createElement("tr");

      const idTd = document.createElement("td");
      idTd.textContent = sub.id;

      const emailTd = document.createElement("td");
      emailTd.textContent = sub.email;

      const dateTd = document.createElement("td");
      dateTd.textContent = formatDate(sub.createdAt);

      const actionTd = document.createElement("td");
      const delBtn = document.createElement("button");
      delBtn.textContent = "Eliminar";
      delBtn.className = "btn btn-danger";
      delBtn.addEventListener("click", () => deleteSubscriber(sub.id));
      actionTd.appendChild(delBtn);

      tr.append(idTd, emailTd, dateTd, actionTd);
      tbody.appendChild(tr);
    }
  } catch (err) {
    setMessage("Error al cargar los suscriptores.", "error");
  }
}

async function deleteSubscriber(id) {
  if (!confirm(`¿Eliminar el suscriptor #${id}?`)) {
    return;
  }

  try {
    const response = await fetch(`/api/subscribers/${id}`, {
      method: "DELETE",
      credentials: "same-origin",
    });

    if (response.status === 204) {
      setMessage("Suscriptor eliminado.", "success");
      loadSubscribers();
    } else {
      const data = await response.json().catch(() => ({}));
      setMessage(data.message || "No se pudo eliminar.", "error");
    }
  } catch (err) {
    setMessage("Error de conexión al eliminar.", "error");
  }
}

refreshBtn.addEventListener("click", loadSubscribers);
loadSubscribers();
