package com.laberit.hospitalslanding.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EnvironmentVariableResponse {
    private String key;
    private String value;
}
