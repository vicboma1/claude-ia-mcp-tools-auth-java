# 🧪 Testing & Docker - Hospitals Landing

## 📋 Resumen

Se han implementado tests completos para validar toda la funcionalidad de MongoDB y se ha creado un Dockerfile para ejecutar la aplicación en contenedor con compilación y tests automáticos.

---

## 🧪 Tests Implementados

### 1. SearchSnapshotServiceTest
**Ubicación**: `src/test/java/.../service/SearchSnapshotServiceTest.java`

Tests unitarios del servicio de captura de snapshots:
- ✅ `testCaptureSearchSnapshot` - Captura general de snapshots
- ✅ `testCaptureCreate` - Captura de CREATE
- ✅ `testCaptureDelete` - Captura de DELETE
- ✅ `testCaptureListSearch` - Captura de LIST
- ✅ `testGetSnapshotsByTab` - Obtener por tab
- ✅ `testGetSnapshotsByTabAndAction` - Obtener por tab y acción
- ✅ `testGetSnapshotsByDateRange` - Obtener por rango de fechas
- ✅ `testGetTabSnapshotCount` - Contar snapshots
- ✅ `testCaptureWithEmptyResults` - Captura con resultados vacíos
- ✅ `testConvertSubscriberResponseToMap` - Conversión de datos

**Total**: 10 tests unitarios

### 2. SearchSnapshotRepositoryTest
**Ubicación**: `src/test/java/.../repository/SearchSnapshotRepositoryTest.java`

Tests de integración con MongoDB:
- ✅ `testFindByTab` - Buscar por tab
- ✅ `testFindByAction` - Buscar por acción
- ✅ `testFindByTabAndAction` - Buscar por tab y acción
- ✅ `testFindByTimestampBetween` - Buscar por fecha
- ✅ `testFindByTabAndDateRange` - Buscar por tab y fecha
- ✅ `testFindByPerformedBy` - Buscar por usuario
- ✅ `testCountByTab` - Contar por tab
- ✅ `testSaveAndFind` - Guardar y recuperar
- ✅ `testDeleteSnapshot` - Eliminar snapshot
- ✅ `testFindByTabReturnsEmptyWhenNotFound` - Resultado vacío
- ✅ `testMultipleSnapshots` - Múltiples snapshots
- ✅ `testResultCountIsPreserved` - Preservar contador
- ✅ `testDetailsFieldIsPreserved` - Preservar detalles

**Total**: 13 tests de integración

### 3. SearchSnapshotControllerTest
**Ubicación**: `src/test/java/.../controller/SearchSnapshotControllerTest.java`

Tests de la API REST:
- ✅ `testGetSnapshotsByTab` - GET /tab/{tab}
- ✅ `testGetSnapshotsByTabAndAction` - GET /tab/{tab}/action/{action}
- ✅ `testGetSnapshotsByDateRange` - GET /date-range
- ✅ `testGetSnapshotsByTabAndDateRange` - GET /tab/{tab}/date-range
- ✅ `testGetTabSnapshotCount` - GET /tab/{tab}/count
- ✅ `testGetSnapshotsByTabReturnsEmpty` - Resultado vacío
- ✅ `testGetSnapshotsByActionDelete` - GET de DELETE
- ✅ `testMultipleSnapshots` - Múltiples snapshots
- ✅ `testSnapshotResponseContainsAllFields` - Validar campos

**Total**: 9 tests de API

---

## 🧬 Cobertura de Tests

```
Total Tests: 32
├─ Unitarios: 10 (SearchSnapshotService)
├─ Integración: 13 (SearchSnapshotRepository)
└─ API REST: 9 (SearchSnapshotController)

Cobertura:
✅ Captura de snapshots (CREATE, DELETE, LIST)
✅ Búsquedas por tab, acción, fecha
✅ Conversión de datos
✅ Endpoints REST
✅ Validación de campos
✅ Casos límite (vacío, múltiple, etc)
```

---

## 🚀 Cómo Ejecutar Tests

### Opción 1: Con el Script (Recomendado)

```bash
# Dar permisos de ejecución
chmod +x scripts/build-and-test.sh

# Ejecutar
./scripts/build-and-test.sh
```

El script automáticamente:
1. ✅ Verifica Maven
2. ✅ Limpia builds anteriores
3. ✅ Compila el proyecto
4. ✅ Ejecuta tests unitarios
5. ✅ Ejecuta tests de integración (si MongoDB está disponible)
6. ✅ Genera reporte de cobertura

### Opción 2: Directamente con Maven

```bash
# Todos los tests
mvn test

# Solo tests unitarios
mvn test -Dtest=SearchSnapshotServiceTest,SearchSnapshotControllerTest

# Solo tests de MongoDB
mvn test -Dtest=SearchSnapshotRepositoryTest

# Con cobertura
mvn test jacoco:report
# Reporte en: target/site/jacoco/index.html
```

### Opción 3: Desde IDE

**IntelliJ IDEA**:
- Right-click en test file → Run
- O presionar `Ctrl+Shift+F10`

**VS Code**:
- Click en "Run" encima del método de test
- O `Ctrl+Shift+D`

---

## 🐳 Docker

### Dockerfile

```dockerfile
# Stage 1: Maven builder
FROM maven:3.9.4-eclipse-temurin-17-alpine AS builder
  - Compila el proyecto
  - Ejecuta todos los tests
  - Genera JAR

# Stage 2: Runtime
FROM eclipse-temurin:17-jre-alpine
  - Ejecuta la aplicación compilada
  - Health checks incluidos
```

### Construcción

#### Con Script (Recomendado)

```bash
# Dar permisos
chmod +x scripts/docker-build-test.sh

# Ejecutar
./scripts/docker-build-test.sh
```

#### Manualmente

```bash
# Compilar imagen (esto ejecuta los tests internamente)
docker build -t hospitals-landing:latest .

# Ver imágenes creadas
docker images | grep hospitals-landing

# Ver logs de compilación si algo falló
docker build --progress=plain -t hospitals-landing:latest .
```

### Ejecutar Contenedor

#### Con docker-compose (Recomendado)

```bash
# Ver variables de entorno disponibles
cat .env.example

# Copiar archivo de configuración
cp .env.example .env

# Levantar todo el stack
docker-compose -f docker-compose.mongodb.yml up -d
# O con la app incluida:
docker-compose -f docker-compose.full.yml up -d

# Ver logs
docker-compose logs -f

# Detener
docker-compose down
```

#### Con docker run

```bash
# Ejecutar solo la app
docker run -it --rm \
  -p 8080:8080 \
  -e DB_HOST=host.docker.internal \
  -e MONGO_HOST=host.docker.internal \
  -e REDIS_HOST=host.docker.internal \
  hospitals-landing:latest

# Con red de Docker
docker network create hospitals-net
docker run -it --rm \
  --network hospitals-net \
  -p 8080:8080 \
  hospitals-landing:latest
```

---

## 📊 Composición de Servicios

### docker-compose.mongodb.yml (Recomendado para desarrollo)

```
postgres:5432        ← Base de datos principal
mongodb:27017        ← Snapshots MongoDB
redis:6379           ← Caché
mongo-express:8081   ← UI MongoDB
```

### docker-compose.full.yml (Desarrollo completo con app)

```
postgres:5432        ← Base de datos
mongodb:27017        ← Snapshots
redis:6379           ← Caché
mongo-express:8081   ← UI MongoDB
app:8080             ← Aplicación Spring Boot
```

---

## 🔄 Flujo Completo: Desarrollo → Docker

```bash
# 1. Clonar y preparar
git clone ...
cd hospitals-landing
cp .env.example .env

# 2. Compilar y validar localmente
./scripts/build-and-test.sh

# 3. Compilar imagen Docker
./scripts/docker-build-test.sh

# 4. Ejecutar con docker-compose
docker-compose -f docker-compose.mongodb.yml up -d

# 5. Acceder
# App: http://localhost:8080/admin.html
# MongoDB UI: http://localhost:8081
# PostgreSQL: localhost:5432
# Redis: localhost:6379
```

---

## ✅ Validación Post-Deploy

### Health Checks Incluidos

```bash
# Verificar que los contenedores están saludables
docker-compose ps

# Resultado esperado:
# STATUS: Up (healthy)
```

### Tests en Producción

```bash
# Ejecutar tests contra app en Docker
docker-compose -f docker-compose.full.yml exec app \
  mvn test -Dtest=SearchSnapshotServiceTest

# Ver logs
docker-compose logs app

# Probar endpoints
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers
```

---

## 📈 Cobertura de Código

### Generar Reporte

```bash
# Con Maven
mvn clean test jacoco:report

# Reporte en: target/site/jacoco/index.html
```

### Visualizar

```bash
# Abrir en navegador
open target/site/jacoco/index.html

# O en Linux
xdg-open target/site/jacoco/index.html
```

### Métricas Esperadas

```
SearchSnapshotService:  >90% de cobertura
SearchSnapshotRepository: >85% de cobertura
SearchSnapshotController: >90% de cobertura
```

---

## 🐛 Troubleshooting

### Tests Fallan Localmente

```bash
# 1. Verificar que MongoDB está corriendo
docker-compose -f docker-compose.mongodb.yml up -d

# 2. Limpiar y reintentar
mvn clean test -U

# 3. Ver logs detallados
mvn test -X
```

### Docker Build Falla

```bash
# 1. Limpiar imágenes anteriores
docker rmi hospitals-landing:latest

# 2. Compilar con logs detallados
docker build --progress=plain -t hospitals-landing:latest .

# 3. Verificar recursos (Docker Desktop)
# Necesita: 4GB RAM mínimo, 2GB espacio libre
```

### Contenedor No Inicia

```bash
# 1. Ver logs
docker-compose logs app

# 2. Verificar que las BD están listas
docker-compose ps
# Todos deben estar: Up (healthy)

# 3. Esperar más tiempo
# Las BD tardan ~30 segundos en estar listas
```

---

## 📦 Archivos Añadidos

```
Tests:
✅ src/test/java/.../service/SearchSnapshotServiceTest.java
✅ src/test/java/.../repository/SearchSnapshotRepositoryTest.java
✅ src/test/java/.../controller/SearchSnapshotControllerTest.java

Docker:
✅ Dockerfile
✅ .dockerignore
✅ docker-compose.full.yml (nuevo)
✅ docker-compose.mongodb.yml (actualizado)

Scripts:
✅ scripts/build-and-test.sh
✅ scripts/docker-build-test.sh
```

---

## 🎯 Checklist de Validación

Antes de hacer push, ejecuta:

```bash
# 1. Tests locales
./scripts/build-and-test.sh
# ✅ Todos deben pasar

# 2. Build Docker
./scripts/docker-build-test.sh
# ✅ Imagen debe compilarse exitosamente

# 3. Stack en Docker
docker-compose -f docker-compose.mongodb.yml up -d
# ✅ Todos los servicios deben estar healthy

# 4. Verificar endpoints
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers
# ✅ Response JSON válido

# 5. Acceder al admin
# ✅ http://localhost:8080/admin.html funciona
# ✅ Tab MongoDB visible
```

---

## 📚 Documentación Relacionada

- `START_HERE.md` - Guía rápida
- `QUICK_START_MONGODB.md` - Instalación
- `ARCHITECTURE.md` - Diagramas del sistema
- `API_EXAMPLES.md` - Ejemplos de API

---

## 🚀 Resumen

✅ **32 tests** implementados y validados
✅ **Dockerfile** con compilación y tests automáticos
✅ **docker-compose** con todas las dependencias
✅ **Scripts** para facilitar build y testing
✅ **Health checks** para validar estado
✅ **Cobertura completa** de la funcionalidad MongoDB

**Todo listo para producción** 🎉
