document.addEventListener('DOMContentLoaded', function() {
    const snapshotsTab = document.getElementById('snapshots-tab');
    if (!snapshotsTab) return;

    const API_BASE = '/api/admin/search-snapshots';
    let allSnapshots = [];

    function formatDate(timestamp) {
        return new Date(timestamp).toLocaleString('es-ES');
    }

    function downloadJSON(data, filename) {
        const json = JSON.stringify(data, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }

    function renderSnapshots(snapshots) {
        const container = document.getElementById('snapshots-list') || createSnapshotsContainer();

        if (!snapshots.length) {
            container.innerHTML = '<p class="text-muted">No hay snapshots disponibles</p>';
            return;
        }

        container.innerHTML = snapshots.map(snapshot => `
            <div class="snapshot-card card mb-3">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <strong>${snapshot.tab}</strong>
                            <span class="badge bg-info">${snapshot.action}</span>
                            <small class="text-muted">${formatDate(snapshot.timestamp)}</small>
                        </div>
                        <div>
                            <button class="btn btn-sm btn-outline-primary" onclick="downloadSnapshot('${snapshot.id}')">
                                📥 Descargar JSON
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <p class="mb-2"><strong>Detalles:</strong> ${snapshot.details}</p>
                    <p class="mb-2"><strong>Registros:</strong> ${snapshot.resultCount}</p>
                    <p class="mb-0"><strong>Usuario:</strong> ${snapshot.performedBy}</p>
                    ${snapshot.resultCount > 0 ? `
                        <button class="btn btn-sm btn-outline-secondary mt-2" onclick="toggleResultsView('${snapshot.id}')">
                            👁️ Ver resultados
                        </button>
                        <div id="results-${snapshot.id}" class="results-view mt-2" style="display:none;">
                            <pre class="bg-light p-2">${JSON.stringify(snapshot.results, null, 2)}</pre>
                        </div>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    function createSnapshotsContainer() {
        const container = document.createElement('div');
        container.id = 'snapshots-list';
        snapshotsTab.appendChild(container);
        return container;
    }

    window.toggleResultsView = function(snapshotId) {
        const resultsDiv = document.getElementById(`results-${snapshotId}`);
        if (resultsDiv) {
            resultsDiv.style.display = resultsDiv.style.display === 'none' ? 'block' : 'none';
        }
    };

    window.downloadSnapshot = function(snapshotId) {
        const snapshot = allSnapshots.find(s => s.id === snapshotId);
        if (snapshot) {
            downloadJSON(snapshot, `snapshot-${snapshot.tab}-${snapshot.action}-${Date.now()}.json`);
        }
    };

    async function loadSnapshots(tab = 'subscribers') {
        try {
            const response = await fetch(`${API_BASE}/tab/${tab}`);
            if (response.ok) {
                allSnapshots = await response.json();
                renderSnapshots(allSnapshots);
            } else {
                console.error('Error loading snapshots:', response.statusText);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    async function loadSnapshotsByAction(tab = 'subscribers', action) {
        try {
            const response = await fetch(`${API_BASE}/tab/${tab}/action/${action}`);
            if (response.ok) {
                allSnapshots = await response.json();
                renderSnapshots(allSnapshots);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    async function loadSnapshotsByDateRange(startDate, endDate, tab = 'subscribers') {
        try {
            const response = await fetch(`${API_BASE}/tab/${tab}/date-range?start=${startDate.toISOString()}&end=${endDate.toISOString()}`);
            if (response.ok) {
                allSnapshots = await response.json();
                renderSnapshots(allSnapshots);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    async function getSnapshotCount(tab = 'subscribers') {
        try {
            const response = await fetch(`${API_BASE}/tab/${tab}/count`);
            if (response.ok) {
                const count = await response.json();
                const countElement = document.getElementById('snapshots-count');
                if (countElement) {
                    countElement.textContent = `Total: ${count} snapshots`;
                }
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    window.SnapshotsAPI = {
        loadSnapshots,
        loadSnapshotsByAction,
        loadSnapshotsByDateRange,
        getSnapshotCount,
        downloadSnapshot
    };

    loadSnapshots();
    getSnapshotCount();
});
