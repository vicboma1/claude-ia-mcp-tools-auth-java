package com.laberit.hospitalslanding.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app.redis")
@Data
public class RedisProperties {
    private boolean enabled = true;
    private long ttl = 0;
    private int maxConnections = 8;
    private int minIdleConnections = 0;
}
