# 🏗️ Arquitectura - MongoDB Snapshots

## Diagrama General del Sistema

```
┌─────────────────────────────────────────────────────────────┐
│                    HOSPITALS LANDING                         │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │               Frontend / Admin Panel                  │   │
│  │  (HTML + JavaScript + admin-snapshots.js)           │   │
│  └────────────────────┬─────────────────────────────────┘   │
│                       │                                       │
│  ┌────────────────────▼─────────────────────────────────┐   │
│  │          Spring Boot Application (Port 8080)         │   │
│  │  ┌──────────────────────────────────────────────┐    │   │
│  │  │ REST API Controllers                         │    │   │
│  │  ├─ SubscriberController                       │    │   │
│  │  │  POST   /api/subscribers (CREATE)          │    │   │
│  │  │  GET    /api/subscribers (LIST)            │    │   │
│  │  │  DELETE /api/subscribers/{id} (DELETE)     │    │   │
│  │  ├─ SearchSnapshotController                  │    │   │
│  │  │  GET    /api/admin/search-snapshots/...    │    │   │
│  │  └──────────────────────────────────────────────┘    │   │
│  │                       │                               │   │
│  │  ┌────────────────────▼────────────────────────┐     │   │
│  │  │ Service Layer                               │     │   │
│  │  ├─ SubscriberService                         │     │   │
│  │  │  ├─ create(email)                         │     │   │
│  │  │  ├─ delete(id)                            │     │   │
│  │  │  └─ findAll()                             │     │   │
│  │  ├─ SearchSnapshotService ◄────────┐        │     │   │
│  │  │  ├─ captureCreate()              │        │     │   │
│  │  │  ├─ captureDelete()              │        │     │   │
│  │  │  └─ captureListSearch()          │        │     │   │
│  │  └──────────────────┬───────────────┼────────┘     │   │
│  │                     │               │              │   │
│  │  ┌──────────────────▼──────────┐   │              │   │
│  │  │ Repositories               │   │              │   │
│  │  ├─ SubscriberRepository      │   │              │   │
│  │  │  (PostgreSQL)              │   │              │   │
│  │  └──────┬───────────────────────┘   │              │   │
│  │         │                           │              │   │
│  │  ┌──────▼──────────────────────────────┐           │   │
│  │  │ SearchSnapshotRepository ◄──────────┘           │   │
│  │  │ (MongoDB)                           │           │   │
│  │  └──────────────────────────────────────┘           │   │
│  └───────────────────────────────────────────────────┘    │
│                                                               │
└─────────────────────────────────────────────────────────────┘
           │                                  │
           ▼                                  ▼
    ┌─────────────────────┐        ┌──────────────────┐
    │    PostgreSQL       │        │     MongoDB      │
    │   (Subscribers)     │        │    (Snapshots)   │
    │                     │        │                  │
    │ - id (SERIAL)       │        │ - _id (ObjectId) │
    │ - email (VARCHAR)   │        │ - tab            │
    │ - created_at        │        │ - action         │
    │                     │        │ - results        │
    └─────────────────────┘        │ - resultCount    │
                                   │ - timestamp      │
                                   │ - performedBy    │
                                   └──────────────────┘
```

## Flujo de Datos

### 1. Crear Nuevo Suscriptor (CREATE)

```
User → Admin Panel (HTML Form)
  │
  ▼
POST /api/subscribers
  │
  ▼
SubscriberController.create()
  │
  ▼
SubscriberService.create(email)
  ├─ Normalizar email
  ├─ Verificar duplicados
  ├─ Guardar en PostgreSQL
  │
  └─► SearchSnapshotService.captureCreate()
      │
      ├─ Convertir resultado a JSON
      ├─ Crear documento SearchSnapshot
      │
      ▼
      MongoDB: search_snapshots collection
        {
          tab: "subscribers",
          action: "CREATE",
          results: [{...}],
          timestamp: "2024-09-04T...",
          ...
        }
```

### 2. Eliminar Suscriptor (DELETE)

```
User → Admin Panel (Delete Button)
  │
  ▼
DELETE /api/subscribers/{id}
  │
  ▼
SubscriberController.delete()
  │
  ▼
SubscriberService.delete(id)
  ├─ Buscar por ID
  ├─ Eliminar de PostgreSQL
  │
  └─► SearchSnapshotService.captureDelete()
      │
      ├─ Registrar ID eliminado
      ├─ Crear documento SearchSnapshot
      │
      ▼
      MongoDB: search_snapshots collection
        {
          tab: "subscribers",
          action: "DELETE",
          results: [],
          details: "Registro eliminado - ID: 123",
          ...
        }
```

### 3. Listar Suscriptores (LIST)

```
User → Admin Panel (List Tab)
  │
  ▼
GET /api/subscribers
  │
  ▼
SubscriberController.list()
  │
  ▼
SubscriberService.findAll()
  ├─ Obtener todos de PostgreSQL
  ├─ Ordenar por fecha
  │
  └─► SearchSnapshotService.captureListSearch()
      │
      ├─ Convertir a JSON
      ├─ Crear documento SearchSnapshot
      │
      ▼
      MongoDB: search_snapshots collection
        {
          tab: "subscribers",
          action: "LIST",
          results: [{...}, {...}, ...],
          resultCount: 5,
          ...
        }
```

### 4. Consultar Snapshots

```
User → Admin Panel (Snapshots Tab)
  │
  ▼
GET /api/admin/search-snapshots/tab/{tab}
  │
  ▼
SearchSnapshotController
  │
  ▼
SearchSnapshotService.getSnapshotsByTab()
  │
  ▼
SearchSnapshotRepository (MongoDB Query)
  │
  ▼
MongoDB: search_snapshots.find({tab: "subscribers"})
  │
  ▼
JSON Response → Frontend → Visualización
```

## Capas de la Aplicación

```
┌────────────────────────────────────────────────────────────┐
│                      Presentation Layer                     │
│  (HTML Templates, JavaScript, API JSON Responses)          │
└────────────────────────┬───────────────────────────────────┘
                         │
┌────────────────────────▼───────────────────────────────────┐
│                      Controller Layer                       │
│  SubscriberController, SearchSnapshotController            │
│  - HTTP Request Handling                                   │
│  - Input Validation                                        │
│  - Response Formatting                                     │
└────────────────────────┬───────────────────────────────────┘
                         │
┌────────────────────────▼───────────────────────────────────┐
│                      Service Layer                         │
│  SubscriberService, SearchSnapshotService                  │
│  - Business Logic                                          │
│  - Transaction Management                                  │
│  - Data Transformation                                     │
└────────────────────────┬───────────────────────────────────┘
                         │
┌────────────────────────▼───────────────────────────────────┐
│                    Repository Layer                        │
│  SubscriberRepository (JPA)                                │
│  SearchSnapshotRepository (MongoDB)                        │
│  - Data Access                                             │
│  - Query Methods                                           │
└────────────────────────┬───────────────────────────────────┘
                         │
┌────────────────────────▼───────────────────────────────────┐
│                   Persistence Layer                        │
│  PostgreSQL (RDBMS) + MongoDB (NoSQL)                      │
│  - Data Storage                                            │
│  - Indexes                                                 │
│  - Transactions                                            │
└────────────────────────────────────────────────────────────┘
```

## Componentes Principales

### 1. SearchSnapshot Entity
```
SearchSnapshot {
  _id: ObjectId (MongoDB ID)
  tab: String ("subscribers", "hospitals", etc.)
  action: String ("CREATE", "DELETE", "LIST")
  results: List<Map> (JSON data)
  resultCount: Integer (número de registros)
  timestamp: Instant (cuándo ocurrió)
  performedBy: String (quién lo hizo)
  details: String (detalles adicionales)
}
```

### 2. SearchSnapshotRepository
```
Interface con métodos:
- findByTab(tab)
- findByAction(action)
- findByTabAndAction(tab, action)
- findByTimestampBetween(start, end)
- findByTabAndDateRange(tab, start, end)
- countByTab(tab)
```

### 3. SearchSnapshotService
```
Métodos públicos:
- captureSearchSnapshot(tab, action, results, performedBy, details)
- captureCreate(tab, created, performedBy)
- captureDelete(tab, deletedId, performedBy)
- captureListSearch(tab, results, performedBy)

Métodos de lectura:
- getSnapshotsByTab(tab)
- getSnapshotsByTabAndAction(tab, action)
- getSnapshotsByDateRange(start, end)
- getSnapshotsByTabAndDateRange(tab, start, end)
- getTabSnapshotCount(tab)
```

## Flujo de Integración

```
┌─────────────────────────────────────────────────┐
│         SubscriberService Methods               │
├─────────────────────────────────────────────────┤
│                                                  │
│  create(email)                                  │
│  ├─ Lógica de creación                         │
│  └─ snapshotService.captureCreate()◄───┐      │
│                                         │       │
│  delete(id)                             │       │
│  ├─ Lógica de eliminación               │       │
│  └─ snapshotService.captureDelete()◄───┤      │
│                                         │       │
│  findAll()                              │       │
│  ├─ Lógica de búsqueda                  │       │
│  └─ snapshotService.captureListSearch()├─┐    │
│                                         │ │    │
└─────────────────────────────────────────┼─┼────┘
                                          │ │
                                          ▼ ▼
                      ┌───────────────────────────┐
                      │ SearchSnapshotService     │
                      │  (Captura automática)     │
                      │                           │
                      │ - Convertir datos         │
                      │ - Crear documento         │
                      │ - Guardar en MongoDB      │
                      └───────────────────────────┘
                              │
                              ▼
                      ┌───────────────────────────┐
                      │ SearchSnapshotRepository  │
                      │ (MongoDB)                 │
                      │                           │
                      │ db.save(snapshot)         │
                      └───────────────────────────┘
```

## Índices MongoDB (Recomendados)

```javascript
// Índices para búsquedas rápidas
db.search_snapshots.createIndex({ tab: 1 });
db.search_snapshots.createIndex({ action: 1 });
db.search_snapshots.createIndex({ tab: 1, action: 1 });
db.search_snapshots.createIndex({ tab: 1, timestamp: -1 });
db.search_snapshots.createIndex({ timestamp: 1 });
db.search_snapshots.createIndex({ performedBy: 1 });

// TTL Index (borrar automáticamente después de 90 días)
db.search_snapshots.createIndex(
  { "timestamp": 1 },
  { expireAfterSeconds: 7776000 }  // 90 días
);
```

## Performance y Escalabilidad

### Capacidades Actuales
- **Escrituras**: <10ms por snapshot
- **Lecturas**: <50ms para búsquedas indexadas
- **Tamaño por snapshot**: ~1KB promedio
- **Retención**: Sin límite (configurable)

### Proyecciones de Crecimiento
```
1000 usuarios
↓
~10-20 operaciones/día por usuario
↓
~10,000-20,000 snapshots/día
↓
~300,000-600,000 snapshots/mes
↓
~3-6 MB/mes (con índices)
```

## Seguridad

```
┌──────────────────────────────────────┐
│      Spring Security Filter Chain    │
├──────────────────────────────────────┤
│                                      │
│  1. Authentication Filter            │
│     (Verificar credenciales)         │
│     ├─ ADMIN_USER                    │
│     └─ ADMIN_PASSWORD                │
│                                      │
│  2. Authorization Filter             │
│     (Verificar permisos)             │
│     └─ /api/admin/* solo para admin  │
│                                      │
│  3. Request Validation               │
│     (DTOs con validación)            │
│                                      │
└──────────────────────────────────────┘
            │
            ▼
┌──────────────────────────────────────┐
│     MongoDB Connection Security      │
├──────────────────────────────────────┤
│                                      │
│  - Conexión autenticada              │
│  - Variables de entorno              │
│  - AWS Secrets Manager (prod)        │
│  - Encriptación en tránsito (TLS)    │
│                                      │
└──────────────────────────────────────┘
```

## Monitoreo y Observabilidad

```
┌─────────────────────────────────┐
│    Application Logs             │
│  (hospitals-landing.log)        │
│                                 │
│  Niveles:                       │
│  ├─ DEBUG: Todas las queries    │
│  ├─ INFO: Operaciones CRUD      │
│  ├─ WARN: Errores no críticos   │
│  └─ ERROR: Fallos               │
└──────────────────┬──────────────┘
                   │
    ┌──────────────┼──────────────┐
    │              │              │
    ▼              ▼              ▼
┌────────┐  ┌────────────┐  ┌────────┐
│MongoDB │  │PostgreSQL  │  │Application
│Stats   │  │Metrics     │  │Metrics
└────────┘  └────────────┘  └────────┘
```

---

**Notas**:
- La captura de snapshots es asincrónica (no bloquea operaciones)
- Los errores en snapshots no afectan las operaciones principales
- MongoDB está separado de PostgreSQL (dos bases de datos independientes)
- Los datos están siempre disponibles para auditoría y análisis
