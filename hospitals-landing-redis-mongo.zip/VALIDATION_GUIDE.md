# ✅ GUÍA DE VALIDACIÓN - Tests y Docker

## 🎯 Objetivo

Validar que toda la implementación de MongoDB, tests y Docker funciona correctamente.

---

## ✅ PASO 1: Validar Estructura de Archivos

```bash
# Verificar que todos los archivos existen
ls -la src/test/java/com/laberit/hospitalslanding/service/SearchSnapshotServiceTest.java
ls -la src/test/java/com/laberit/hospitalslanding/repository/SearchSnapshotRepositoryTest.java
ls -la src/test/java/com/laberit/hospitalslanding/controller/SearchSnapshotControllerTest.java
ls -la Dockerfile
ls -la .dockerignore
ls -la docker-compose.mongodb.yml
ls -la docker-compose.full.yml
ls -la scripts/build-and-test.sh
ls -la scripts/docker-build-test.sh
```

**Resultado esperado**: ✅ Todos los archivos existen

---

## ✅ PASO 2: Compilar Localmente con Tests

### Opción A: Con Script (Más Fácil)

```bash
# Dar permisos
chmod +x scripts/build-and-test.sh

# Ejecutar
./scripts/build-and-test.sh
```

**Resultado esperado**:
```
✅ Compilación exitosa
✅ Tests unitarios pasados
✅ Verificación completa exitosa
```

### Opción B: Directamente con Maven

```bash
# Compilar
mvn clean compile

# Ejecutar tests unitarios
mvn test -Dtest=SearchSnapshotServiceTest,SearchSnapshotControllerTest
```

**Resultado esperado**:
```
Tests run: 19, Failures: 0, Skips: 0
✅ BUILD SUCCESS
```

---

## ✅ PASO 3: Tests de Integración (MongoDB)

### Levantar MongoDB

```bash
# Copiar configuración
cp .env.example .env

# Levantar servicios
docker-compose -f docker-compose.mongodb.yml up -d

# Esperar ~30 segundos
sleep 30

# Verificar estado
docker-compose ps
```

**Resultado esperado**:
```
STATUS: Up (healthy) para PostgreSQL, MongoDB, Redis
```

### Ejecutar Tests de Integración

```bash
# Tests del repositorio MongoDB
mvn test -Dtest=SearchSnapshotRepositoryTest

# O todos los tests
mvn test
```

**Resultado esperado**:
```
Tests run: 13, Failures: 0, Skips: 0
✅ BUILD SUCCESS
```

---

## ✅ PASO 4: Compilar Imagen Docker

### Con Script

```bash
chmod +x scripts/docker-build-test.sh
./scripts/docker-build-test.sh
```

### Manualmente

```bash
docker build -t hospitals-landing:latest .
```

**Resultado esperado**:
```
Successfully tagged hospitals-landing:latest
✅ BUILD COMPLETE
```

### Verificar Imagen

```bash
# Ver imagen creada
docker images | grep hospitals-landing

# Ejecutar la imagen
docker run -it --rm hospitals-landing:latest
```

**Resultado esperado**:
```
REPOSITORY              TAG       IMAGE ID
hospitals-landing       latest    abc123def456
✅ Tomcat started on port 8080
```

---

## ✅ PASO 5: Stack Completo en Docker

### Levantar Stack

```bash
# Ver variables disponibles
cat .env.example

# Copiar configuración (si no la tienes)
cp .env.example .env

# Levantar stack completo
docker-compose -f docker-compose.full.yml up -d

# Esperar que todo esté listo (~1 minuto)
sleep 30

# Ver estado
docker-compose ps
```

**Resultado esperado**:
```
NAME                STATUS
hospitals-postgres      Up (healthy)
hospitals-mongodb       Up (healthy)
hospitals-redis         Up (healthy)
hospitals-mongo-express Up
hospitals-landing       Up (healthy)
```

---

## ✅ PASO 6: Validar Endpoints

### Healthcheck de la Aplicación

```bash
# Verificar que la app responde
curl http://localhost:8080/actuator/health
```

**Resultado esperado**:
```json
{"status":"UP"}
```

### Verificar API de Snapshots

```bash
# Obtener snapshots de suscriptores
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers

# Contar snapshots
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers/count

# Filtrar por acción
curl "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE"
```

**Resultado esperado**:
```json
[]  // Lista vacía (no hay datos aún)
0   // Contador = 0

HTTP 200 OK
```

---

## ✅ PASO 7: Validar UI Admin

### Acceder al Admin Panel

```
URL: http://localhost:8080/admin.html
Usuario: admin
Contraseña: changeme
```

**Resultado esperado**:
- ✅ Login exitoso
- ✅ Ver 4 tabs: Suscriptores, MongoDB, Redis, Variables de Entorno
- ✅ Tab MongoDB visible y cargable

### Crear Datos de Prueba

1. Ve al tab **Suscriptores**
2. Crea un nuevo email: `test@example.com`
3. Ve al tab **MongoDB**
4. Presiona **Actualizar**
5. Deberías ver 1 snapshot con action **CREATE**

**Resultado esperado**:
```
Tab: suscriptores
Action: CREATE
Registros: 1
Timestamp: (ahora)
Detalles: Nuevo registro creado
```

### Probar Más Operaciones

```bash
# Desde otra terminal, crear más datos
curl -X POST http://localhost:8080/api/subscribers \
  -H "Content-Type: application/json" \
  -d '{"email": "otro@example.com"}'

curl -X POST http://localhost:8080/api/subscribers \
  -H "Content-Type: application/json" \
  -d '{"email": "tercero@example.com"}'

curl http://localhost:8080/api/subscribers
```

**Resultado esperado**:
- 3 nuevos snapshots en MongoDB tab (3 CREATE + 1 LIST = 4 total)

---

## ✅ PASO 8: Validar MongoDB UI

### Acceder a Mongo Express

```
URL: http://localhost:8081
Usuario: admin
Contraseña: password
```

**Resultado esperado**:
- ✅ Login exitoso
- ✅ Ver base de datos `hospitals-snapshots`
- ✅ Ver colección `search_snapshots`
- ✅ Ver documentos JSON de los snapshots

### Ver Documentos

```
hospitals-snapshots → search_snapshots
```

Cada documento debe tener:
```json
{
  "_id": ObjectId,
  "tab": "subscribers",
  "action": "CREATE|DELETE|LIST",
  "results": [...],
  "resultCount": number,
  "timestamp": ISODate,
  "performedBy": "system",
  "details": string
}
```

---

## ✅ PASO 9: Tests de Cobertura

### Generar Reporte

```bash
mvn clean test jacoco:report
```

### Ver Reporte

```bash
# Abrir en navegador
open target/site/jacoco/index.html

# O en Linux
xdg-open target/site/jacoco/index.html
```

**Resultado esperado**:
- SearchSnapshotService: >90% coverage
- SearchSnapshotRepository: >85% coverage
- SearchSnapshotController: >90% coverage

---

## ✅ PASO 10: Validar Limpieza

### Detener Contenedores

```bash
docker-compose -f docker-compose.full.yml down
```

**Resultado esperado**:
```
Stopping hospitals-landing ... done
Stopping hospitals-postgres ... done
Removing containers
✅ Done
```

### Verificar que no quedó nada

```bash
docker ps | grep hospitals
# Debe estar vacío

docker-compose ps
# Error: not specified in the compose file
# ✅ Correcto
```

---

## 📋 CHECKLIST DE VALIDACIÓN

Marca cada paso completado:

```
ESTRUCTURA:
□ Archivos de test existen
□ Dockerfile existe
□ .dockerignore existe
□ docker-compose files existen
□ Scripts existen

COMPILACIÓN LOCAL:
□ mvn compile funciona
□ Tests unitarios pasan (19 tests)
□ Verificación Maven exitosa

DOCKER:
□ Imagen compila exitosamente
□ docker-compose.mongodb.yml levanta correctamente
□ docker-compose.full.yml levanta correctamente
□ Todos los servicios están "healthy"

API:
□ Healthcheck responde
□ GET /api/admin/search-snapshots retorna JSON
□ Crear email → snapshot aparece
□ Eliminar email → snapshot aparece
□ Listar emails → snapshot aparece

UI:
□ Login funciona
□ Tab MongoDB visible
□ Snapshots aparecen en tabla
□ Filtros funcionan
□ Descargar JSON funciona

MONGODB:
□ Mongo Express accesible
□ Documentos JSON visibles
□ Campos correctos en documentos

COBERTURA:
□ Reporte genera correctamente
□ Cobertura > 80%
```

---

## 🚨 Si Algo Falla

### Paso 1: Verificar Logs

```bash
# Tests
mvn test -X

# Docker
docker-compose logs -f

# Aplicación
docker logs hospitals-landing
```

### Paso 2: Limpiar y Reintentar

```bash
# Detener todo
docker-compose down -v

# Limpiar Maven
mvn clean

# Limpiar Docker
docker system prune -a

# Reintentar desde Paso 1
```

### Paso 3: Verificar Recursos

```bash
# Espacio en disco
df -h

# RAM disponible
free -h  # Linux
vm_stat  # macOS
```

Requiere: 4GB RAM mínimo, 2GB espacio libre

---

## ✅ RESUMEN DE VALIDACIÓN

Si todo pasó, tienes:

```
✅ 32 Tests funcionando
  ├─ 10 Unitarios (SearchSnapshotService)
  ├─ 13 Integración (SearchSnapshotRepository)
  └─ 9 API REST (SearchSnapshotController)

✅ Dockerfile compilando y ejecutando tests
  ├─ Stage 1: Maven builder
  └─ Stage 2: Runtime

✅ docker-compose completo
  ├─ PostgreSQL
  ├─ MongoDB
  ├─ Redis
  ├─ Mongo Express
  └─ Aplicación Spring Boot

✅ API funcionando
  ├─ Snapshots guardándose
  ├─ Búsquedas funcionando
  └─ Endpoints respondiendo

✅ UI Admin
  ├─ Tab MongoDB visible
  ├─ Datos apareciendo
  └─ Filtros funcionando

✅ MongoDB
  ├─ Mongo Express accesible
  ├─ Documentos JSON guardados
  └─ Datos correctos
```

---

## 🎉 ¡LISTO!

Tu implementación de MongoDB, tests y Docker está **100% validada y funcional**.

**Próximos pasos**:
1. Hacer push a Git
2. Configurar CI/CD (GitHub Actions, GitLab CI, etc)
3. Desplegar a producción

---

## 📞 Referencia Rápida

```bash
# Compilar y tests
./scripts/build-and-test.sh

# Docker build
./scripts/docker-build-test.sh

# Docker compose
docker-compose -f docker-compose.mongodb.yml up -d
docker-compose -f docker-compose.full.yml up -d

# Acceder
Admin: http://localhost:8080/admin.html
MongoDB UI: http://localhost:8081
API: http://localhost:8080/api/admin/search-snapshots/...

# Ver logs
docker-compose logs -f
mvn test -X

# Limpiar
docker-compose down -v
mvn clean
```

---

**Validación completada exitosamente** ✅
