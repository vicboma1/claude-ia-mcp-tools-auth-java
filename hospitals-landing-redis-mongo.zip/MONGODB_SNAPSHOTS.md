# MongoDB Search Snapshots - Réplicas de Búsquedas

## Descripción

Este módulo captura automáticamente **réplicas (snapshots)** de todas las operaciones realizadas en el panel de administración (CRUD operations) y las almacena en MongoDB en formato JSON.

## Características

✅ **Captura Automática**: Se registran automáticamente cuando:
- Se crea un nuevo registro (`CREATE`)
- Se elimina un registro (`DELETE`)
- Se realiza una búsqueda/listado (`LIST`)

✅ **Almacenamiento JSON**: Los resultados se guardan como documentos JSON en MongoDB

✅ **Filtrado por Tab**: Cada pestaña del admin tiene sus propios snapshots (ej: `subscribers`)

✅ **Filtrado por Acción**: Puedes consultar snapshots por tipo de acción (CREATE, DELETE, LIST)

✅ **Consultas por Rango de Fechas**: Filtra snapshots por período de tiempo

✅ **Descarga de JSON**: Descarga snapshots individuales o en lote como archivos JSON

## Instalación y Configuración

### 1. Dependencia MongoDB

La dependencia ya está agregada en `pom.xml`:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-mongodb</artifactId>
</dependency>
```

### 2. Variables de Entorno

Configura los siguientes valores en tu entorno:

```bash
# MongoDB local (desarrollo)
MONGO_HOST=localhost
MONGO_PORT=27017
MONGO_DB=hospitals-snapshots

# O usa una URI directa
MONGODB_URI=mongodb://localhost:27017/hospitals-snapshots
```

### 3. AWS Secrets Manager (Producción)

Si usas el perfil `aws`, agrega estas credenciales al secreto:

```json
{
  "MONGO_HOST": "mi-mongodb.xxxxx.eu-west-1.docdb.amazonaws.com",
  "MONGO_PORT": "27017",
  "MONGO_DB": "hospitals-snapshots",
  "MONGODB_URI": "mongodb://user:pass@mi-mongodb.xxxxx.eu-west-1.docdb.amazonaws.com:27017/hospitals-snapshots"
}
```

### 4. Docker Compose (Opcional)

Para levantar MongoDB localmente:

```bash
docker run -d -p 27017:27017 --name mongodb mongo:latest
```

O con Docker Compose:

```yaml
version: '3.8'
services:
  mongodb:
    image: mongo:latest
    container_name: hospitals-mongodb
    ports:
      - "27017:27017"
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: password
      MONGO_INITDB_DATABASE: hospitals-snapshots
    volumes:
      - mongodb_data:/data/db

volumes:
  mongodb_data:
```

## Estructura del Snapshot

Cada snapshot capturado tiene la siguiente estructura JSON:

```json
{
  "_id": "ObjectId",
  "tab": "subscribers",
  "action": "CREATE|DELETE|LIST",
  "results": [
    {
      "id": 1,
      "email": "user@example.com",
      "createdAt": "2024-09-04T12:00:00Z"
    }
  ],
  "resultCount": 1,
  "timestamp": "2024-09-04T12:00:00Z",
  "performedBy": "system|admin|user",
  "details": "Descripción de la operación"
}
```

## API Endpoints

### Obtener snapshots por Tab

```http
GET /api/admin/search-snapshots/tab/{tab}
```

**Ejemplo:**
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers
```

### Obtener snapshots por Tab y Acción

```http
GET /api/admin/search-snapshots/tab/{tab}/action/{action}
```

**Ejemplo:**
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE
```

### Obtener snapshots por Rango de Fechas

```http
GET /api/admin/search-snapshots/date-range?start={ISO8601}&end={ISO8601}
```

**Ejemplo:**
```bash
curl "http://localhost:8080/api/admin/search-snapshots/date-range?start=2024-09-01T00:00:00Z&end=2024-09-05T00:00:00Z"
```

### Obtener snapshots por Tab y Rango de Fechas

```http
GET /api/admin/search-snapshots/tab/{tab}/date-range?start={ISO8601}&end={ISO8601}
```

**Ejemplo:**
```bash
curl "http://localhost:8080/api/admin/search-snapshots/tab/subscribers/date-range?start=2024-09-01T00:00:00Z&end=2024-09-05T00:00:00Z"
```

### Obtener contador de snapshots por Tab

```http
GET /api/admin/search-snapshots/tab/{tab}/count
```

**Ejemplo:**
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers/count
```

## Uso desde el Frontend

El archivo `admin-snapshots.js` proporciona la API JavaScript:

```javascript
// Cargar todos los snapshots de una pestaña
SnapshotsAPI.loadSnapshots('subscribers');

// Cargar snapshots por acción
SnapshotsAPI.loadSnapshotsByAction('subscribers', 'CREATE');

// Cargar snapshots por rango de fechas
const start = new Date('2024-09-01');
const end = new Date('2024-09-05');
SnapshotsAPI.loadSnapshotsByDateRange(start, end, 'subscribers');

// Obtener contador
SnapshotsAPI.getSnapshotCount('subscribers');

// Descargar un snapshot como JSON
SnapshotsAPI.downloadSnapshot(snapshotId);
```

## Integración en el HTML del Admin

Agrega esta línea en tu template HTML del admin:

```html
<script src="/js/admin-snapshots.js"></script>
```

Y crea un contenedor para los snapshots:

```html
<div id="snapshots-tab">
    <h3>Réplicas de Búsquedas</h3>
    <div id="snapshots-count" class="alert alert-info"></div>
    <div id="snapshots-list"></div>
</div>
```

## Consultas MongoDB (mongosh)

### Ver todos los snapshots de una tab

```javascript
db.search_snapshots.find({ tab: "subscribers" }).pretty()
```

### Ver snapshots de una acción específica

```javascript
db.search_snapshots.find({ tab: "subscribers", action: "CREATE" }).pretty()
```

### Ver snapshots en un rango de fechas

```javascript
db.search_snapshots.find({
  timestamp: {
    $gte: ISODate("2024-09-01"),
    $lte: ISODate("2024-09-05")
  }
}).pretty()
```

### Contar snapshots por tab

```javascript
db.search_snapshots.countDocuments({ tab: "subscribers" })
```

### Ver el tamaño total de snapshots

```javascript
db.search_snapshots.stats().size
```

## Monitoreo y Mantenimiento

### Limpiar snapshots antiguos (más de 90 días)

```javascript
db.search_snapshots.deleteMany({
  timestamp: {
    $lt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
  }
})
```

### Crear índice para optimizar búsquedas

```javascript
db.search_snapshots.createIndex({ tab: 1, timestamp: -1 })
db.search_snapshots.createIndex({ action: 1 })
```

## Troubleshooting

### MongoDB no se conecta

Verifica que:
1. MongoDB está corriendo: `curl http://localhost:27017`
2. Las variables de entorno están configuradas correctamente
3. Los logs contienen el mensaje de conexión: `Data Aggregators started`

### Los snapshots no se guardan

Revisa los logs para:
- Errores de permisos en MongoDB
- Errores de deserialización JSON
- Excepciones en `SearchSnapshotService`

### Logs relevantes

```bash
# Ver errores de MongoDB
tail -f logs/hospitals-landing.log | grep -i mongodb

# Ver operaciones de snapshots
tail -f logs/hospitals-landing.log | grep -i snapshot
```

## Performance

- **Almacenamiento**: ~1KB por snapshot promedio
- **Lectura**: <50ms para búsquedas indexadas
- **Escritura**: <10ms por snapshot (asincrónico)

## Seguridad

- Los snapshots se capturan automáticamente sin intervención del usuario
- Se registra el usuario/sistema que realizó la operación
- Los datos JSON incluyen toda la información de los registros
- Implementa políticas de retención (cleanup automático) según regulaciones

## Roadmap Futuro

- [ ] Exportación masiva de snapshots a CSV/Excel
- [ ] Comparación entre snapshots (diff)
- [ ] Auditoría avanzada con roles/permisos
- [ ] Compresión automática de snapshots antiguos
- [ ] Webhook para notificar cambios
