#!/bin/bash

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${BLUE}  🧪 Build & Test - Hospitals Landing  ${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}\n"

# Verificar que Maven está instalado
if ! command -v mvn &> /dev/null; then
    echo -e "${RED}❌ Maven no está instalado${NC}"
    echo "Instálalo con: sudo apt-get install maven"
    exit 1
fi

echo -e "${YELLOW}📋 Información del Proyecto:${NC}"
echo "Java Version:"
java -version 2>&1 | head -1
echo "Maven Version:"
mvn -version | head -1
echo ""

# Limpiar builds anteriores
echo -e "${YELLOW}🧹 Limpiando builds anteriores...${NC}"
mvn clean -q

# Compilar
echo -e "${YELLOW}🔨 Compilando proyecto...${NC}"
mvn compile -q
echo -e "${GREEN}✅ Compilación exitosa${NC}\n"

# Ejecutar tests unitarios
echo -e "${YELLOW}🧪 Ejecutando tests unitarios...${NC}"
mvn test -q \
    -Dtest=SearchSnapshotServiceTest \
    -Dtest=SearchSnapshotControllerTest

TEST_RESULT=$?
if [ $TEST_RESULT -eq 0 ]; then
    echo -e "${GREEN}✅ Tests unitarios pasados${NC}\n"
else
    echo -e "${RED}❌ Tests unitarios fallaron${NC}\n"
    exit 1
fi

# Ejecutar tests de integración
echo -e "${YELLOW}🗄️  Ejecutando tests de integración (MongoDB)...${NC}"
echo "⚠️  Estos tests requieren MongoDB corriendo"
echo ""

# Verificar si MongoDB está corriendo
if ! nc -z localhost 27017 2>/dev/null; then
    echo -e "${YELLOW}📝 MongoDB no está disponible. Saltando tests de integración.${NC}"
    echo "Para ejecutar tests de MongoDB:"
    echo "  docker-compose -f docker-compose.mongodb.yml up -d"
    echo "  mvn test -Dtest=SearchSnapshotRepositoryTest"
else
    echo -e "${YELLOW}✅ MongoDB detectado en localhost:27017${NC}"
    mvn test -q -Dtest=SearchSnapshotRepositoryTest
    INTEGRATION_RESULT=$?
    if [ $INTEGRATION_RESULT -eq 0 ]; then
        echo -e "${GREEN}✅ Tests de integración pasados${NC}\n"
    else
        echo -e "${RED}⚠️  Tests de integración fallaron${NC}\n"
        echo "Nota: Esto puede ser normal si MongoDB no está accesible"
    fi
fi

# Ejecutar todos los tests
echo -e "${YELLOW}📦 Compilando JAR con verificación completa...${NC}"
mvn verify -q
VERIFY_RESULT=$?

if [ $VERIFY_RESULT -eq 0 ]; then
    echo -e "${GREEN}✅ Verificación completa exitosa${NC}\n"
else
    echo -e "${RED}❌ Verificación fallida${NC}\n"
    exit 1
fi

# Mostrar resumen
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ BUILD Y TESTS COMPLETADOS EXITOSAMENTE${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}\n"

echo -e "${YELLOW}📊 Resumen:${NC}"
echo "✅ Compilación: EXITOSA"
echo "✅ Tests unitarios: EXITOSOS"
echo "✅ Verificación Maven: EXITOSA"
echo ""

echo -e "${YELLOW}📦 Artefactos generados:${NC}"
ls -lh target/hospitals-landing.jar 2>/dev/null && echo "✅ JAR compilado" || echo "⚠️  JAR no encontrado"
echo ""

echo -e "${YELLOW}🚀 Próximos pasos:${NC}"
echo ""
echo "Opción 1: Ejecutar con Docker"
echo "  docker build -t hospitals-landing:latest ."
echo "  docker-compose -f docker-compose.full.yml up -d"
echo ""
echo "Opción 2: Ejecutar localmente"
echo "  mvn spring-boot:run"
echo ""
echo "Opción 3: Ejecutar JAR compilado"
echo "  java -jar target/hospitals-landing.jar"
echo ""
echo -e "${BLUE}════════════════════════════════════════${NC}\n"
