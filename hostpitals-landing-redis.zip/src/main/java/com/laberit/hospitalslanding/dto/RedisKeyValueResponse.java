package com.laberit.hospitalslanding.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RedisKeyValueResponse {
    private String key;
    private String value;
}
