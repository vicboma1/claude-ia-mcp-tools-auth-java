# 🚀 Quick Start - MongoDB Snapshots

## 1️⃣ Clonar las Variables de Entorno

```bash
cp .env.example .env
```

Los valores por defecto están listos para desarrollo local.

## 2️⃣ Levantar MongoDB con Docker

```bash
docker-compose -f docker-compose.mongodb.yml up -d
```

Espera ~10 segundos para que MongoDB esté listo.

### Verificar que MongoDB está corriendo:
```bash
docker ps | grep mongodb
```

## 3️⃣ Compilar el Proyecto

```bash
mvn clean install
```

## 4️⃣ Ejecutar la Aplicación

```bash
mvn spring-boot:run
```

O con tu IDE favorito (IntelliJ, VS Code, Eclipse, etc.)

## 5️⃣ Acceder a las Herramientas

### 🌐 Aplicación
- **Landing Page**: http://localhost:8080/
- **Admin Panel**: http://localhost:8080/admin.html
- **Credenciales**: admin / changeme

### 📊 MongoDB UI (Mongo Express)
- **URL**: http://localhost:8081
- **Usuario**: admin
- **Contraseña**: password
- **Base de datos**: hospitals-snapshots
- **Colección**: search_snapshots

## 6️⃣ Prueba el Sistema

### Desde el Admin Panel:
1. Ve a http://localhost:8080/admin.html
2. Inicia sesión (admin/changeme)
3. Crea un nuevo suscriptor con un email
4. Elimina un suscriptor
5. Lista los suscriptores
6. Verás que cada operación genera un snapshot

### Ver Snapshots en MongoDB UI:
1. Ve a http://localhost:8081
2. Navega a: hospitals-snapshots → search_snapshots
3. Verás todos los snapshots en formato JSON

## 7️⃣ Usar la API de Snapshots

### Listar todos los snapshots de una tab:
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers
```

### Listar snapshots por acción:
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers/action/CREATE
```

### Descargar como JSON:
```bash
curl http://localhost:8080/api/admin/search-snapshots/tab/subscribers > snapshots.json
```

## 🛑 Detener los Servicios

```bash
# Detener MongoDB
docker-compose -f docker-compose.mongodb.yml down

# Detener la aplicación
# Presiona Ctrl+C en la terminal donde está corriendo
```

## 📝 Logging

Ver los logs en tiempo real:
```bash
tail -f logs/hospitals-landing.log | grep -i snapshot
```

## 🔧 Troubleshooting

### "Connection refused" en MongoDB
```bash
# Reinicia MongoDB
docker-compose -f docker-compose.mongodb.yml restart mongodb

# O elimina y recrea
docker-compose -f docker-compose.mongodb.yml down
docker-compose -f docker-compose.mongodb.yml up -d
```

### "No snapshots available"
- Asegúrate de haber realizado operaciones en el admin (crear/eliminar suscriptores)
- Verifica que MongoDB está corriendo: `docker ps | grep mongodb`

### Puerto 27017 ya está en uso
```bash
# Cambiar el puerto en docker-compose.mongodb.yml
ports:
  - "27018:27017"  # Usar 27018 en lugar de 27017
```

## 📚 Próximos Pasos

- Lee [MONGODB_SNAPSHOTS.md](./MONGODB_SNAPSHOTS.md) para documentación completa
- Implementa políticas de retención para limpiar snapshots antiguos
- Configura alertas en producción
- Integra con tu sistema de auditoría/compliance

## 💡 Tips

- Los snapshots se capturan automáticamente sin intervención del usuario
- Cada snapshot incluye un timestamp para auditoría
- Los datos JSON son descargables para análisis externo
- MongoDB escala automáticamente con el crecimiento de datos
