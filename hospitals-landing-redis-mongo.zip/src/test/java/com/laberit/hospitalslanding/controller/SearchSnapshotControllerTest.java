package com.laberit.hospitalslanding.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.laberit.hospitalslanding.dto.SearchSnapshotResponse;
import com.laberit.hospitalslanding.model.SearchSnapshot;
import com.laberit.hospitalslanding.service.SearchSnapshotService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SearchSnapshotController.class)
class SearchSnapshotControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SearchSnapshotService service;

    private SearchSnapshot testSnapshot;
    private SearchSnapshotResponse testResponse;

    @BeforeEach
    void setUp() {
        testSnapshot = SearchSnapshot.builder()
                .id("507f1f77bcf86cd799439011")
                .tab("subscribers")
                .action("CREATE")
                .results(List.of(Map.of("id", 1, "email", "test@example.com")))
                .resultCount(1)
                .timestamp(Instant.now())
                .performedBy("system")
                .details("Test snapshot")
                .build();

        testResponse = SearchSnapshotResponse.from(testSnapshot);
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testGetSnapshotsByTab() throws Exception {
        when(service.getSnapshotsByTab("subscribers"))
                .thenReturn(List.of(testSnapshot));

        mockMvc.perform(get("/api/admin/search-snapshots/tab/subscribers"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].tab").value("subscribers"))
                .andExpect(jsonPath("$[0].action").value("CREATE"));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testGetSnapshotsByTabAndAction() throws Exception {
        when(service.getSnapshotsByTabAndAction("subscribers", "CREATE"))
                .thenReturn(List.of(testSnapshot));

        mockMvc.perform(get("/api/admin/search-snapshots/tab/subscribers/action/CREATE"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].action").value("CREATE"));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testGetSnapshotsByDateRange() throws Exception {
        when(service.getSnapshotsByDateRange(any(Instant.class), any(Instant.class)))
                .thenReturn(List.of(testSnapshot));

        mockMvc.perform(get("/api/admin/search-snapshots/date-range")
                .param("start", "2024-09-01T00:00:00Z")
                .param("end", "2024-09-05T00:00:00Z"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$", hasSize(1)));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testGetSnapshotsByTabAndDateRange() throws Exception {
        when(service.getSnapshotsByTabAndDateRange(eq("subscribers"), any(Instant.class), any(Instant.class)))
                .thenReturn(List.of(testSnapshot));

        mockMvc.perform(get("/api/admin/search-snapshots/tab/subscribers/date-range")
                .param("start", "2024-09-01T00:00:00Z")
                .param("end", "2024-09-05T00:00:00Z"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].tab").value("subscribers"));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testGetTabSnapshotCount() throws Exception {
        when(service.getTabSnapshotCount("subscribers")).thenReturn(5L);

        mockMvc.perform(get("/api/admin/search-snapshots/tab/subscribers/count"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$").value(5));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testGetSnapshotsByTabReturnsEmpty() throws Exception {
        when(service.getSnapshotsByTab("nonexistent"))
                .thenReturn(List.of());

        mockMvc.perform(get("/api/admin/search-snapshots/tab/nonexistent"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$", hasSize(0)));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testGetSnapshotsByActionDelete() throws Exception {
        SearchSnapshot deleteSnapshot = SearchSnapshot.builder()
                .tab("subscribers")
                .action("DELETE")
                .results(List.of())
                .resultCount(0)
                .timestamp(Instant.now())
                .performedBy("admin")
                .details("Deleted ID: 1")
                .build();

        when(service.getSnapshotsByTabAndAction("subscribers", "DELETE"))
                .thenReturn(List.of(deleteSnapshot));

        mockMvc.perform(get("/api/admin/search-snapshots/tab/subscribers/action/DELETE"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].action").value("DELETE"))
                .andExpect(jsonPath("$[0].resultCount").value(0));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testMultipleSnapshots() throws Exception {
        SearchSnapshot snap1 = testSnapshot;
        SearchSnapshot snap2 = SearchSnapshot.builder()
                .tab("subscribers")
                .action("LIST")
                .results(List.of(Map.of("id", 1, "email", "test1@example.com"),
                        Map.of("id", 2, "email", "test2@example.com")))
                .resultCount(2)
                .timestamp(Instant.now())
                .performedBy("system")
                .details("List all")
                .build();

        when(service.getSnapshotsByTab("subscribers"))
                .thenReturn(List.of(snap1, snap2));

        mockMvc.perform(get("/api/admin/search-snapshots/tab/subscribers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].action").value("CREATE"))
                .andExpect(jsonPath("$[1].action").value("LIST"));
    }

    @Test
    @WithMockUser(username = "admin", roles = "ADMIN")
    void testSnapshotResponseContainsAllFields() throws Exception {
        when(service.getSnapshotsByTab("subscribers"))
                .thenReturn(List.of(testSnapshot));

        mockMvc.perform(get("/api/admin/search-snapshots/tab/subscribers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").exists())
                .andExpect(jsonPath("$[0].tab").exists())
                .andExpect(jsonPath("$[0].action").exists())
                .andExpect(jsonPath("$[0].results").exists())
                .andExpect(jsonPath("$[0].resultCount").exists())
                .andExpect(jsonPath("$[0].timestamp").exists())
                .andExpect(jsonPath("$[0].performedBy").exists())
                .andExpect(jsonPath("$[0].details").exists());
    }
}
