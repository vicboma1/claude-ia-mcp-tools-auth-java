package com.laberit.hospitalslanding.dto;

import com.laberit.hospitalslanding.model.SearchSnapshot;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SearchSnapshotResponse {

    private String id;
    private String tab;
    private String action;
    private List<Map<String, Object>> results;
    private Integer resultCount;
    private Instant timestamp;
    private String performedBy;
    private String details;

    public static SearchSnapshotResponse from(SearchSnapshot snapshot) {
        return SearchSnapshotResponse.builder()
                .id(snapshot.getId())
                .tab(snapshot.getTab())
                .action(snapshot.getAction())
                .results(snapshot.getResults())
                .resultCount(snapshot.getResultCount())
                .timestamp(snapshot.getTimestamp())
                .performedBy(snapshot.getPerformedBy())
                .details(snapshot.getDetails())
                .build();
    }
}
