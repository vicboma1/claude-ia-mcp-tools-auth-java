document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("subscribe-form");
const emailInput = document.getElementById("email");
const messageEl = document.getElementById("form-message");

function setMessage(text, type) {
  messageEl.textContent = text;
  messageEl.classList.remove("success", "error");
  if (type) {
    messageEl.classList.add(type);
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const email = emailInput.value.trim();

  if (!email) {
    setMessage("Introduce un correo.", "error");
    return;
  }

  const submitBtn = form.querySelector("button[type=submit]");
  submitBtn.disabled = true;
  setMessage("Enviando…", null);

  try {
    const response = await fetch("/api/subscribers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    if (response.status === 201) {
      setMessage("¡Gracias! Te avisaremos por correo.", "success");
      form.reset();
    } else {
      const data = await response.json().catch(() => ({}));
      setMessage(data.message || "No se pudo completar el registro.", "error");
    }
  } catch (err) {
    setMessage("Error de conexión. Inténtalo de nuevo.", "error");
  } finally {
    submitBtn.disabled = false;
  }
});
